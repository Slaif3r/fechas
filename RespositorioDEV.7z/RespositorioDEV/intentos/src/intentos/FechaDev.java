package intentos;

import java.awt.List;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class FechaDev {
	
	private static List<> fechaEntrada (String num_dias, LocalDate fecha_actual){
		LocalDate fecha_actual;
		List<LocalDate> listaFechas = new ArrayList<LocalDate>();
		
		
		return listaFechas;
	}

}
