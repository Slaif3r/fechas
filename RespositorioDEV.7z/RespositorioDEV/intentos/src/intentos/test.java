package intentos;

import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;



public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	    Month month = null;
	    LocalDate date = null;
	    DateTimeFormatter format;
	    String out = null;

	    month = Month.valueOf("May".toUpperCase());
	    date =LocalDate.of(2017,7,29);

	    LocalDate nextPayday = date.with(new PaydayAdjuster());

	    format = DateTimeFormatter.ofPattern("yyyy MMM d");
	    out = date.format(format);
	    System.out.printf("Given the date:  %s%n", out);
	    out = nextPayday.format(format);
	    System.out.printf("the next payday: %s%n", out);
	  }

	}


