package intentos;

import java.time.LocalDate;
import java.time.DayOfWeek;
import java.time.DateTimeException;

import java.time.temporal.Temporal;
import java.time.temporal.TemporalAdjuster;
import java.time.temporal.TemporalAdjusters;

import java.io.PrintStream;

public class PaydayAdjuster  implements TemporalAdjuster {
 
    public Temporal adjustInto(Temporal input) {
        LocalDate date = LocalDate.from(input);
        int day = 0;
        LocalDate date15Day,date30Day;
        
        
        date15Day = date;
       /* if (date.getDayOfMonth() < 15) {
            day = 15;
        } */if (date.lengthOfMonth() == 31){
            day = date.with(TemporalAdjusters.lastDayOfMonth()).getDayOfMonth()-1;
            day = day/2;
        }else {day =date.with(TemporalAdjusters.lastDayOfMonth()).getDayOfMonth();day = day/2;}
        
        date = date.plusDays(day);
        
        if (date.getDayOfWeek() == DayOfWeek.SUNDAY) 
        {date = date.with(TemporalAdjusters.previous(DayOfWeek.SATURDAY));}
        date30Day = date;
        adjustInto(date30Day);
        return date ;//date;//input.with(date);
        
        
    } 
} 

