package test;

import com.bgeneral.canales.validadigito.*;


public class test {
	
	
	public static void main(String[] args) {
      try{
    	//Cedula persona natural//Funciona Correctamente      
    	  ValidaDigito.ValidarContrato("LL-LL-9999-999999","S","F",0,14,"14","05",2,"06  0055000408",47,"47");
    	  
    	  //Cedula persona Extranjera(Letra E)
    	  ValidaDigito.ValidarContrato("LL-LL-9999-999999","S","F",0,14,"14","05",2,"00E 0008047337",02,"02");

    	  //Cedula persona Extranjera(Letra N)

    	  ValidaDigito.ValidarContrato("LL-LL-9999-999999","S","F",0,14,"14","05",2,"00N 0013000395",68,"68");

    	  //RUC PLNUEVO
    	  ValidaDigito.ValidarContrato("9999999-9999-999999","S","F",0,17,"12","05",76,"00661590091363381",5,"05");

    	  //RUC PLVIEJO
    	  ValidaDigito.ValidarContrato("9999999-9999-999999","S","F",0,17,"12","05",76,"00037240103053659",43,"43");

    	  //Juridica NT
    	  ValidaDigito.ValidarContrato("9999999999-LLLL-999999","S","F",0,20,"17","05",285,"00000352260002259295",36,"36");

    	  //RUC FOLIO REAL ELECTRONICOW
    	  ValidaDigito.ValidarContrato("LL-LL-9999-999999","S","F",0,14,"13","05",77,"08NT0001023224",50,"50");


    	  //Inmuble Empezando con F 
    	  ValidaDigito.ValidarContrato("L-9-L-99999-L","S","F",0,9,"06","05",7,"F3005799A",31,"31");

    	  //Inmueble Nuevo
    	  ValidaDigito.ValidarContrato("XXXXXXXXXXXXXX-XXXX","S","V",1,19,"15","05",135,"301275200 5A11",80,"80");


    	  ValidaDigito.ValidarContrato("XXXXXXXXXXXXXX-XXXX","S","V",1,19,"15","05",135,"48248 8705",27,"27");


    	  //Idaan 
    	  ValidaDigito.ValidarContrato("99999999-L","N","F",0,9,"02","4",4,"006230830",0,"");

    	  //Cuenta CW 
    	   ValidaDigito.ValidarContrato("99-999999-9999-9","N","F",0,13,"03","05",4,"1540832200003",0,"0");

    	  //Validar Cedula Sola
    	  ValidaDigito.ValidarContrato("LL-LL-9999-999999","N","F",0,14,"08","02",1,"08  0088300870",0,"0");

    	  //Inmueble Variable
    	  ValidaDigito.ValidarContrato("XXXXXXXXXXXXXX-XXXX","S","V",1,19,"15","05",135,"91653 8708",07,"07");

    	  //Gas natural Fenosa(Edemeth Edechi)

    	  ValidaDigito.ValidarContrato("9999999999","N","F",0,10,"04","17",5,"5093622002",0,"");

    	  //Valida Generico
    	  ValidaDigito.ValidarContrato("99-AA-99","N","F",0,06,"01","18",86,"22AA22",0,"0");
	      
	     }
	       catch (ErrorEnEjecucionExcepcion e){
	    	   System.out.println(e.getCodigoError()+". " + e.getMessage().toString());
	    	   
	       }
      
		   }
}
