package com.bgeneral.canales.validadigito;

import static java.lang.Integer.parseInt;
/**ValidaInmueble: Valida los digitos verificadores de Inmueble.
 * 
 * @author brrodriguez
 *
 */
class ValidaInmueble {
	/**Digito Final, puede ser devuelto si es necesario.*/
	private static String mvarDigitoFin;
	/**Digito Final, puede ser devuelto si es necesario.*/
	private static String VLDigitoVer;
	/**sbrInmuebleDV:  Valida los digitos verificadores de Inmueble en sus diferentes
	 * formatos.
	 * 
	 * @param valor Finca
	 * @param largoMin Largo Minimo de la finca
	 * @param largoMax  Largo Maximo de la finca
	 * @param tipoValidacion 06: INMUEBLE CON DV, 15: INMUEBLE FORMATO CUI 10-011
	 * @param digitoVerificador Digito verificador numerico
	 * @return Retorna true si la verificacion es correcta o excepcion si hay un error.
	 */
	 protected static boolean sbrInmuebleDV(String valor, int largoMin,int largoMax, String tipoValidacion, int digitoVerificador) 
	    { 
	        int pos;
	        String primertext, segundotext, fincaaux, letraaux;
	        boolean error=false, correcto=true;
	        int codigoError=0;

	        if (tipoValidacion.equals("06"))
	        {
	            if (valor.length() < largoMax)
	            {
	            	codigoError=13;
	                error=true;
	            }
	            else if (!(valor.substring(0, 1).equals("D")) && 
	                    !(valor.substring(0, 1).equals("F"))) {
	            	codigoError=14;
	                error=true;
	            }
	            else  if (!(valor.substring(2, 3).equals("H"))
	                    && !(valor.substring(2, 3).equals("K"))
	                    && !(valor.substring(2, 3).equals("P"))
	                    && !(valor.substring(2, 3).equals("R"))
	                   && ((((int) valor.charAt(2) < 48)) || //Compara el caracter de la cadena, contra los valores ASCII
	                    (((int) valor.charAt(2) > 57)))) {

	            	codigoError=15;
	                error=true;
	            }
	            else if (!(valor.substring(8, 9).equals("A")) &&
	                    !(valor.substring(8, 9).equals("B"))
	                    && !(valor.substring(8, 9).equals("C"))
	                    && !(valor.substring(8, 9).equals("D"))
	                    && !(valor.substring(8, 9).equals("E"))
	                    && !(valor.substring(8, 9).equals("F"))
	                    && !(valor.substring(8, 9).equals(" "))
	                    && ((((int) valor.charAt(2) < 48)) || //Compara el caracter de la cadena, contra los valores ASCII
	                        (((int) valor.charAt(2) > 57)))) {
	                
	                
	            	codigoError=16;
	                error=true;
	            }

	            else if ((valor.substring(1, 2).equals("0"))
	                    || (valor.substring(3, 8).equals("00000"))) {
	            	codigoError=17;
	                error=true;
	            }

	            else  if (!(validaDVHAC(valor, "I", String.valueOf(digitoVerificador)))) {
	            	codigoError=27;
	                error=true;
	            }

	        } else if (tipoValidacion.equals("15")) {
	            if ((valor.length() < largoMin)
	                    || (valor.length() > largoMax)) {
	            	codigoError=13;
	                MensajesDeError.lanzaExcepcion(codigoError);
	            }

	            pos = (valor.indexOf(' '));//Trae de la cadena, la posici�n donde se encuentra el espacio
	            if (pos > 0) {
	                primertext = valor.substring(0, pos);
	                segundotext = (valor.substring(pos, valor.length()).trim());
	            } else {
	                primertext = valor.substring(0, 6);
	                segundotext = (valor.substring(6, valor.length()).trim());
	            }
	            letraaux = segundotext.substring(1, 2);

	            if (!(ValidaValor.esNumerico(letraaux))) {
	                switch (letraaux) {
	                    case "A":
	                        letraaux = "1";
	                        break;
	                    case "B":
	                        letraaux = "2";
	                        break;
	                    case "C":
	                        letraaux = "3";
	                        break;
	                    default:
	                    	codigoError=17;
	                        error=true;
	                }
	                segundotext = segundotext.substring(0, 1) + letraaux + segundotext.substring(2, segundotext.length());
	            }
	            fincaaux = primertext.trim() + segundotext.trim();
	            if(fincaaux.length()<10)
	                fincaaux = fincaaux.substring(0,fincaaux.length());
	            else
	            fincaaux = fincaaux.substring(0, 10);

	            if ((primertext.length()) > 14) {
	            	codigoError=13;
	                MensajesDeError.lanzaExcepcion(codigoError);
	            }
	            else if ((segundotext.length()) > 4) {
	            	codigoError=13;
	            	MensajesDeError.lanzaExcepcion(codigoError);
	            }
	            else if (!(ValidaValor.esNumerico(fincaaux))) {
	            	codigoError=17;
	            	MensajesDeError.lanzaExcepcion(codigoError);
	            }
	            else if (!(validaDVHAC(fincaaux, "U", String.valueOf(digitoVerificador)))) {
	            	codigoError=27;
	                error=true;
	                VLDigitoVer="";
	            }
	        }
	        else
	        {
	        	MensajesDeError.lanzaExcepcion(0);
	        }
	        mvarDigitoFin=(VLDigitoVer);
	        if(error){
	        	MensajesDeError.lanzaExcepcion(codigoError);
	        }
	        return correcto;
	    }
	 /**validaDVHAC: Genera el digito verificador y lo compara contra el introducido.
	  * 
	  * @param cadena
	  * @param tipo
	  * @param digito
	  * @return Retorna true si la verificacion es correcta o excepcion si hay un error.
	  */
	 private static boolean validaDVHAC(String cadena, String tipo, String digito) 
	    {
	        String alfa, DVV = "";
	        Long Peso, suma, Residuo, DV = 0L;
	        int longitud, Modulo, i, K;
	        boolean estado; //Devuelve el estado de la funcion
	        if (digito.trim().equals("")) {
	            estado = false;
	            return estado;
	        }
	        
	     
	        
	        if (tipo.equals("I")) {

	            alfa = cadena.substring(0, 1);
	            if (alfa.equals("F")) {
	                cadena = "6" + ValidaValor.cadenaALaDerecha(cadena, cadena.length() - 1);
	            } else if (alfa.equals("D")) {
	                cadena = "4" + ValidaValor.cadenaALaDerecha(cadena, cadena.length() - 1);
	            }
	            alfa = cadena.substring(2, 3);
	            switch (alfa) {
	                case "H":
	                    cadena = (cadena.substring(0, 2)) + "8" + (ValidaValor.cadenaALaDerecha(cadena, cadena.length() - 3));
	                    break;
	                case "K":
	                    cadena = (cadena.substring(0, 2)) + "2" + (ValidaValor.cadenaALaDerecha(cadena, cadena.length() - 3));
	                    break;
	                case "R":
	                    cadena = (cadena.substring(0, 2)) + "9" + (ValidaValor.cadenaALaDerecha(cadena, cadena.length() - 3));
	                    break;
	                case "P":
	                    cadena = (cadena.substring(0, 2)) + "7" + (ValidaValor.cadenaALaDerecha(cadena, cadena.length() - 3));
	                    break;
	            }
	            if ((cadena.trim().length()) == 8) {
	                cadena = cadena.trim() + "0";
	            }
	            alfa = ValidaValor.cadenaALaDerecha(cadena, 1);
	            switch (alfa) {
	                case "A":
	                    cadena = (cadena.substring(0, cadena.length() - 1)) + "1";
	                    break;
	                case "B":
	                    cadena = (cadena.substring(0, cadena.length() - 1)) + "2";
	                    break;
	                case "C":
	                    cadena = (cadena.substring(0, cadena.length() - 1)) + "3";
	                    break;
	                case "D":
	                    cadena = (cadena.substring(0, cadena.length() - 1)) + "4";
	                    break;
	                case "E":
	                    cadena = (cadena.substring(0, cadena.length() - 1)) + "5";
	                    break;
	                case "F":
	                    cadena = (cadena.substring(0, cadena.length() - 1)) + "6";
	                    break;
	            }
	            Peso = 10L;
	            suma = 0L;
	            longitud = 9;
	            Modulo = 11;
	            cadena = ValidaValor.cadenaDinamica('0', (longitud - cadena.length())) + cadena;
	            for (i = 1; i <= 2; i++) {
	                for (K = 1; K <= longitud; K++) {
	                    suma = suma + Peso * parseInt(cadena.substring(K - 1, K));
	                    Peso--;
	                }
	                if (suma > 0) {
	                    Residuo = suma - (Modulo * ((int) (suma / Modulo)));
	                    if (Residuo < 2) {
	                        DV = 0L;
	                    } else {
	                        DV = Modulo - Residuo;
	                    }
	                }
	                Peso = 11L;
	                suma = DV * 2;
	                DVV = DVV.trim() + String.valueOf(DV).trim();
	            }
	        } else if (tipo.equals("U")) {
	            Peso = 11L;
	            suma = 0L;
	            longitud = 10;
	            Modulo = 11;
	            cadena = cadena + ValidaValor.cadenaDinamica('0', (longitud - cadena.length()));
	            for (i = 1; i <= 2; i++) {
	                for (K = 1; K <= longitud; K++) {
	                    suma = suma + Peso * parseInt(cadena.substring(K - 1, K));
	                    Peso = Peso - 1;
	                }
	                if (suma > 0) {
	                    Residuo = suma - (Modulo * ((int) (suma / Modulo)));
	                    if (Residuo < 2) {
	                        DV = 0L;
	                    } else {
	                        DV = Modulo - Residuo;
	                    }
	                }
	                Peso = 12L;
	                suma = DV * 2;
	                DVV = DVV.trim() + String.valueOf(DV).trim();
	            }

	        }
	        else{
	        	MensajesDeError.lanzaExcepcion(0);
	        }

	        estado = parseInt(digito) == parseInt(DVV);

	        return estado;

	    }

	    
}
