package com.bgeneral.canales.validadigito;

import static java.lang.Integer.parseInt;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
/**ValidaValor: Clase de apoyo para realizar las validaciones.
 * 
 * @author brrodriguez
 *
 */
class ValidaValor {
	/**cadenaDinamica: Genera una cadena a partir de una base.
	 * 
	 * @param base Caracter de base.
	 * @param cant Cantidad de veces que la base se genera.
	 * @return Cadena completa.
	 */
	  protected static String cadenaDinamica(char base, int cant) 
	    {
	        char caracterD;
	        String cadenaCompleta = "";
	        caracterD = base;
	        for (int x = 0; x <= (cant - 1); x++) {
	            cadenaCompleta = caracterD + cadenaCompleta;

	        }
	        return cadenaCompleta;
	    }
	  /**esNumerico: Consulta si la cadena es numerica.
	   * 
	   * @param cadena
	   * @return True o false.
	   */
	 protected static boolean esNumerico(String cadena)
	    {
		 boolean numerica=false;
	        try {
	            Double.parseDouble(cadena);

	        } catch (NumberFormatException nfe) {
	            return numerica;
	        }
	        numerica=true;
	        return numerica;
	    }
	 
	 /**cadenaALaDerecha: Devuelve los ultimos caracteres de la cadena solicitados.
	  * 
	  * @param cadena1
	  * @param cantidad
	  * @return Cadena
	  */
	 protected static String cadenaALaDerecha(String cadena1, int cantidad)
	    {
	        String nuevaCadena = "";
	        nuevaCadena=cadena1;
	        try {
	            
	            nuevaCadena=nuevaCadena.substring(nuevaCadena.length()-cantidad, nuevaCadena.length());
	          return nuevaCadena;
	            }
	            
	         catch (Exception e) {
	            return "Error al traer cadena";
	        }
	    }
	 
	 /**Val: Compara si los primeros caracteres de la cadena son numericos.
	  * 
	  * @param cadena
	  * @return Devuelve los primeros numeros de una cadena, si existen.
	  */
	 protected static int Val(String cadena) 
	    {
	       
	        int entero = 0;
	        String sinespacios = cadena.replaceAll("\\s+", "");//ELIMINA TODOS LOS ESPACIOS
	        String regex = "^(\\d+\\.\\d+|\\d+|\\.\\d+)";//DIGITO, DIGITO.DIGITO, 0.DIGITO
	        Pattern pattern = Pattern.compile(regex);
	        Matcher m = pattern.matcher(sinespacios);

	        if (m.find()) {
	            entero = parseInt(m.group(1));
	        } else {
	           
	        }
	        return entero;
	    }
}
