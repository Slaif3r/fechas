package com.bgeneral.canales.validadigito;

import static java.lang.Integer.parseInt;
/**ValidaDigitoImpuestos: Clase encargada de validar los diferentes contratos
 * que utilizen el digito verificador.
 * 
 * @author brrodriguez
 *
 */

class ValidaDigitoImpuestos {
	/**Digito Final, puede ser devuelto si es necesario.*/
	private static String mvarDigitoFin;
	/**Digito Final, puede ser devuelto si es necesario.*/
	private static String VLDigitoVer;
	/**Arreglos que guardan el formato que valida los RUC y cedulas.*/
	private static int[] arr_val = new int[50], arr_dig = new int[50], arr_num = new int[50], arr_ruc = new int[50];
	/**sbrImpuestosConRUC: Recibe los parametros y efectua el proceso de validacion.
	 * 
	 * @param parModo 0: RUC JURIDICO, 1: RUC NT, 2: PERSONA NATURAL, 3: RUC (FOLIO REAL ELECTRONICO) 
	 * @param valor RUC, o Cedula a validar
	 * @param dvChar Digito Verificador Cadena
	 * @param largoMax Largo Maximo del valor
	 * @return
	 */
	protected static boolean sbrImpuestosConRUC(int parModo, String valor, String dvChar, int largoMax) 
	    { //METODO QUE REALIZA LAS DIFERENTES VALIDACIONES DE RUC, CEDULA CON SUS FORMATOS CORRESPONDIENTES
	        String VTNuevoRUC, VTValorRUC;
	        String alfa;
	        String VTCad1, VTCad2, VTCad3;
	        String VTCadAnt, VTCadComp, VTCadComp1, VTCadRel, VTBandera="N";
	        String VTDig1, VTDig2, VTDig6, VTDig7, VTDig3, VTDig4, VTDig5, VTDig13, VTDig45 = "", VTDig67;
	        boolean error=false, correcto=false;
	        int codigoError=0;

	        if (parModo == 0)
	        {
	            if (sbrValida_RUC(valor)) {
	                VTValorRUC = valor;

	                VTNuevoRUC = "000" + VTValorRUC;

	                VTDig1 = String.valueOf(ValidaValor.Val(VTNuevoRUC.substring(0, 1)));
	                VTDig2 = String.valueOf(ValidaValor.Val(VTNuevoRUC.substring(1, 2)));
	                VTDig3 = String.valueOf(ValidaValor.Val(VTNuevoRUC.substring(2, 3)));
	                VTDig4 = String.valueOf(ValidaValor.Val(VTNuevoRUC.substring(3, 4)));
	                VTDig5 = String.valueOf(ValidaValor.Val(VTNuevoRUC.substring(4, 5)));
	                VTDig6 = String.valueOf(ValidaValor.Val(VTNuevoRUC.substring(5, 6)));
	                VTDig7 = String.valueOf(ValidaValor.Val(VTNuevoRUC.substring(6, 7)));

	                VTDig13 = VTNuevoRUC.substring(7, 20);
	                VTDig67 = VTDig6 + VTDig7;

	                if ((VTDig4.equals("0")) && (VTDig5.equals("0")) && (parseInt(VTDig6) < 5)) {

	                    VLDigitoVer=PLViejo(VTDig1, VTDig2, VTDig3, VTDig4, VTDig5, VTDig6, VTDig7, VTDig13, VTDig67);
	                } else {
	                	VLDigitoVer=PLNuevo(VTNuevoRUC);

	                }

	                if (ValidaValor.esNumerico(dvChar)) {
	                    if (ValidaValor.Val(VLDigitoVer) != ValidaValor.Val(dvChar)) {
	                    	codigoError=18;
	                    	error=true;
	                        VLDigitoVer="";
	                    }
	                } else {
	                    if (!(VLDigitoVer.equals(dvChar))) {
	                    	codigoError=18;
	                    	error=true;
	                        VLDigitoVer="";
	                    }
	                }
	                mvarDigitoFin=(VLDigitoVer);
	            }
	        }

	        else if ((parModo == 2) || (parModo == 1)) {
	            VTValorRUC = valor;

	            VTCadComp = ValidaValor.cadenaALaDerecha(VTValorRUC, 6);
	            VTCadComp1 = VTValorRUC.substring(4, (VTValorRUC.length() - 10) + 4);
	            VTCad2 = VTValorRUC.substring(0, 4);

	            if (VTCadComp.substring(0, 1).equals("0")) {

	                VTCad1 = VTValorRUC.substring(VTValorRUC.length() - 5, VTValorRUC.length());
	                VTCadRel = ValidaValor.cadenaALaDerecha(VTValorRUC, VTValorRUC.length() - 5);

	            } else {
	                VTCad1 = VTCadComp;
	                VTBandera = "S";
	            }

	            if (VTCadComp1.substring(0, 1).equals("0")) {
	                VTCad3 = VTValorRUC.substring(5, (VTValorRUC.length() - 11) + 5);

	            } else {
	                VTCad3 = VTCadComp1;
	                VTBandera = "S";
	            }

	            if (VTBandera.equals("S")) {
	                if (parModo == 2) {
	                    VTCadAnt = "0000005";

	                } else {
	                    VTCadAnt = "0000000";
	                }

	            } else {
	                if (parModo == 2) {
	                    VTCadAnt = "00000005";
	                } else {
	                    VTCadAnt = "00000000";
	                }
	            }

	            

	            VTValorRUC = VTCad2 + VTCad3 + VTCad1;

	            VTCadRel = VTCad3 + VTCad1;
	            if (ValidaFormatoCedula.sbrValida_Cedula(valor, largoMax)) {
	                alfa = VTValorRUC.substring(2, 4);
	                switch (alfa) {
	                    case "  ":
	                        VTValorRUC = VTValorRUC.substring(0, 2) + "00" + VTCadRel;
	                        break;
	                    case "NT":
	                        VTValorRUC = VTValorRUC.substring(0, 2) + "43" + VTCadRel;
	                        break;
	                    case "E ":
	                        VTValorRUC = VTValorRUC.substring(0, 2) + "50" + VTCadRel;
	                        break;
	                    case "PE":
	                        VTValorRUC = VTValorRUC.substring(0, 2) + "75" + VTCadRel;
	                        break;
	                    case "PI":
	                        VTValorRUC = VTValorRUC.substring(0, 2) + "79" + VTCadRel;
	                        break;
	                    case "AV":
	                        VTValorRUC = VTValorRUC.substring(0, 2) + "15" + VTCadRel;
	                        break;
	                    case "N ":
	                        VTValorRUC = VTValorRUC.substring(0, 2) + "40" + VTCadRel;
	                        break;
	                }

	                VTNuevoRUC = VTCadAnt + VTValorRUC;

	                VTDig1 = String.valueOf(ValidaValor.Val(VTNuevoRUC.substring(0, 1)));
	                VTDig2 = String.valueOf(ValidaValor.Val(VTNuevoRUC.substring(1, 2)));
	                VTDig3 = String.valueOf(ValidaValor.Val(VTNuevoRUC.substring(2, 3)));
	                VTDig4 = String.valueOf(ValidaValor.Val(VTNuevoRUC.substring(3, 4)));
	                VTDig5 = String.valueOf(ValidaValor.Val(VTNuevoRUC.substring(4, 5)));
	                VTDig13 = (VTNuevoRUC.substring(5, 18));
	                VTDig45 = VTDig4 + VTDig5;

	                VLDigitoVer=PLNuevo(VTNuevoRUC);

	                if (ValidaValor.esNumerico(dvChar)) {
	                    if (ValidaValor.Val(VLDigitoVer) != ValidaValor.Val(dvChar)) {
	                    	codigoError=18;
	                    	error=true;
	                    }
	                } else {
	                    if (!(VLDigitoVer.equals(String.valueOf(dvChar)))) {
	                    	codigoError=18;
	                    	error=true;
	                    }
	                }
	                mvarDigitoFin=(VLDigitoVer);
	            }
	        }

	        else if (parModo == 3)
	        {
	            if (sbrValida_RUC(valor))
	            {
	                VTValorRUC = valor;
	                VTNuevoRUC = VTValorRUC.substring(VTValorRUC.length() - 20, VTValorRUC.length());

	                VTDig1 = String.valueOf(ValidaValor.Val(VTNuevoRUC.substring(0, 1)));
	                VTDig2 = String.valueOf(ValidaValor.Val(VTNuevoRUC.substring(1, 2)));
	                VTDig3 = String.valueOf(ValidaValor.Val(VTNuevoRUC.substring(2, 3)));
	                VTDig4 = String.valueOf(ValidaValor.Val(VTNuevoRUC.substring(3, 4)));
	                VTDig5 = String.valueOf(ValidaValor.Val(VTNuevoRUC.substring(4, 5)));
	                VTDig6 = String.valueOf(ValidaValor.Val(VTNuevoRUC.substring(5, 6)));
	                VTDig7 = String.valueOf(ValidaValor.Val(VTNuevoRUC.substring(6, 7)));
	                VTDig13 = VTNuevoRUC.substring(7, 20);
	                VTDig67 = VTDig6 + VTDig7;
	                VLDigitoVer=(" ");

	                if ((VTDig4.equals("0")) && (VTDig5.equals("0")) && (parseInt(VTDig6) < 5)) {
	                	VLDigitoVer=PLViejo(VTDig1, VTDig2, VTDig3, VTDig4, VTDig5, VTDig6, VTDig7, VTDig13, VTDig67);
	                } else {
	                	VLDigitoVer=PLNuevo(VTNuevoRUC);
	                }

	                if (ValidaValor.esNumerico(dvChar)) {
	                    if (ValidaValor.Val(VLDigitoVer) != (ValidaValor.Val(dvChar))) {
	                    	codigoError=18;
	                    	error=true;
	                    }
	                } else {
	                    if (VLDigitoVer.equals(String.valueOf(dvChar))) {
	                    	codigoError=18;
	                    	error=true;
	                    }
	                }
	                mvarDigitoFin=(VLDigitoVer);
	            }
	        }
	        
	        	else{
	        		MensajesDeError.lanzaExcepcion(0);
	            }
	        if(error){
	        	MensajesDeError.lanzaExcepcion(codigoError);
	        }
	        correcto=true;
	        return correcto;
	    }
	/**
	 * sbrValida_RUC: Valida Ruc que sea valido.
	 * @param parValor
	 * @return
	 */
	 private static boolean sbrValida_RUC(String parValor)
	    {
	    	int codigoError=34;
	    	boolean correcto=true;
	        if (parValor.equals("00099990999999999")) {
	        	MensajesDeError.lanzaExcepcion(codigoError);
	         } 
	        return correcto;
	    }

	/**PLViejo: Valida los RUC que tengan el formato viejo.
	 * 
	 * @param parDig1
	 * @param parDig2
	 * @param parDig3
	 * @param parDig4
	 * @param parDig5
	 * @param parDig6
	 * @param parDig7
	 * @param parDig13
	 * @param parDig45
	 * @return Retorna el digito verificador del valor introducido.
	 */
    private static String PLViejo(String parDig1, String parDig2, String parDig3, String parDig4, String parDig5, String parDig6, String parDig7, String parDig13, String parDig45) 
    {
        
        int i, j, acum, acum1, Residuo, dv1, dv2;
        String VTNuevoRUC;
        PLInicioArreglos();

        for (i = 0; i <= 40; i++) {
            if (arr_val[i] == parseInt(parDig45)) {
                parDig7 = String.valueOf(arr_dig[i]);
                parDig6 = "0";
                i = 41;
            }
        }
        VTNuevoRUC = parDig1 + parDig2 + parDig3 + parDig4 + parDig5 + parDig6 + parDig7 + parDig13;
        j = 20;
        for (i = 0; i <= 19; i++) {
            arr_ruc[i] = ValidaValor.Val(VTNuevoRUC.substring(i, i + 1));
            arr_num[i] = j - i;
            if (i == 10) {
                arr_num[i] = 11;
                j = 21;
            }
        }

        acum = 0;
        acum1 = 0;
        for (i = 0; i <= 19; i++) {
            acum = arr_ruc[i] * arr_num[i];
            acum1 = acum1 + acum;
        }

        Residuo = acum1 % 11;
        if (Residuo == 0 || Residuo == 1) {
            dv1 = 0;
        } else {
            dv1 = 11 - Residuo;
        }

        arr_ruc[20] = dv1;
        j = 21;
        for (i = 0; i <= 20; i++) {
            arr_num[i] = j - i;
            if (i == 11) {
                arr_num[i] = 11;
                j = 22;
            }
        }

        acum = 0;
        acum1 = 0;
        for (i = 0; i <= 20; i++) {
            acum = arr_ruc[i] * arr_num[i];
            acum1 = acum1 + acum;
        }
        Residuo = acum1 % 11;
        if (Residuo == 0 || Residuo == 1) {
            dv2 = 0;
        } else {
            dv2 = 11 - Residuo;
        }

        return (String.valueOf(dv1) + String.valueOf(dv2));
    }
    /**
     * PLNuevo: Valida los RUC que tengan el formato nuevo.
     * @param parNuevoRUC
     * @return Retorna el digito verificador del valor introducido.
     */
    private static String PLNuevo(String parNuevoRUC) 
    {
        
        int i, j, acum, acum1, Residuo, dv1, dv2;
        j = 21;

        for (i = 0; i <= 19; i++) {

            arr_ruc[i] = ValidaValor.Val(parNuevoRUC.substring(i, i + 1));
            arr_num[i] = j - i;
        }
        acum = 0;
        acum1 = 0;

        for (i = 0; i <= 19; i++) {
            acum = arr_ruc[i] * arr_num[i];
            acum1 = acum1 + acum;
        }
        Residuo = acum1 % 11;
        if (Residuo == 0 || Residuo == 1) {
            dv1 = 0;
        } else {
            dv1 = 11 - Residuo;
        }
        arr_ruc[20] = dv1;
        j = 22;

        for (i = 0; i <= 20; i++) {
            arr_num[i] = j - i;
        }
        acum = 0;
        acum1 = 0;
        for (i = 0; i <= 20; i++) {

            acum = arr_ruc[i] * arr_num[i];
            acum1 = acum1 + acum;
        }
        Residuo = acum1 % 11;

        if (Residuo == 0 || Residuo == 1) {
            dv2 = 0;
        } else {
            dv2 = 11 - Residuo;
        }
        return (String.valueOf(dv1) + String.valueOf(dv2));
    }
	
	
	
	
	/**PLInicioArreglos: Inicializa los arreglos con los cuales se comparan los RUC, y cedulas.
	 * @author brrodriguez
	 */
	private static void PLInicioArreglos()
    {
        
        int j, i;
        arr_val[0] = 0;
        j = 10;
        arr_val[1] = 0;
        for (i = 1; i <= 49; i++) {
            arr_val[i] = j;
            j++;
        }
        j = 0;
        arr_dig[0] = 0;
        for (i = 0; i <= 9; i++) {
            arr_dig[i] = j;
            j++;
        }
        j = 1;
        arr_dig[10] = 0;
        for (i = 10; i <= 13; i++) {
            arr_dig[i] = j;
            j++;
        }

        j = 7;
        arr_dig[14] = 0;
        for (i = 14; i <= 16; i++) {
            arr_dig[i] = j;
            j++;
        }

        j = 2;
        arr_dig[17] = 0;
        for (i = 17; i <= 24; i++) {
            arr_dig[i] = j;
            j++;
        }
        j = 1;
        arr_dig[25] = 0;
        for (i = 25; i <= 33; i++) {
            arr_dig[i] = j;
            j++;
        }
        j = 1;
        arr_dig[34] = 0;
        for (i = 34; i <= 40; i++) {
            arr_dig[i] = j;
            j++;
        }
    }
	
	
}
