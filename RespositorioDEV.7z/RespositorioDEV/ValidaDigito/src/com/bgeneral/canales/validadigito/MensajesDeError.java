package com.bgeneral.canales.validadigito;
/**
 * MensajesDeError: Mensajes personalizados por cada error que se genere.
 * @author brrodriguez
 *
 */
class MensajesDeError {

	private static String mensajeDeError(int codigo){
    	String mensaje="";
    	switch(codigo){
    	case 1:
    		mensaje= ("La longitud del campo no es v�lida. Por favor verificar los datos ingresados.");
    		break;
    	case 2: 
    		mensaje=("El campo no cumple con el formato establecido. Por favor verificar los datos ingresados.");
    		break;
    	case 3: 
    		mensaje=("Cuenta invalida. Por favor verifique los datos ingresados.");
    	    break;
    	case 4: 
    		mensaje=("La cuenta no puede ser ceros.");
    		break;
    	case 13:
    		mensaje=("La longitud del n�mero de finca es incorrecta.  Por favor verifique los datos ingresados.");
    		break;
    	case 14:
    		mensaje=("El caracter de la primera posici�n es incorrecto.  Por favor verifique los datos ingresados.");
    		break;
    	case 15:
    		mensaje=("El caracter de la tercera posici�n es incorrecto.  Por favor verifique los datos ingresados.");
    		break;
    	case 16:
    		mensaje=("El caracter de la �ltima posici�n incorrecto. Por favor verifique los datos ingresados.");
    		break;
    	case 17:
    		mensaje=("El inmueble no es v�lido. Por favor verifique los datos ingresados.");
    		break;
    	case 18:
    		mensaje=("El d�gito verificador y/o la identificaci�n est�n incorrectos.  Favor verifique los datos ingresados");
    		break;
    	case 19:
    		mensaje=("La longitud de la c�dula no es correcta. Por favor verifique los datos ingresados.");
    		break;
    	case 20: 
    		mensaje=("El n�mero de provincia no es v�lido. Por favor verifique los datos ingresados.");
    		break;
    	case 21:
    		mensaje=("La clave alfanum�rica de la c�dula no es correcta. Por favor verifique los datos ingresados.");
    		break;
    	case 22:
    		mensaje=("La clave alfanum�rica de la c�dula no corresponde con la provincia. Por favor verifique los datos ingresados.");
    		break;
    	case 23: 
    		mensaje=("El folio debe ser de cuatro d�gitos y el asiento de cinco d�gitos. Por favor verifique los datos ingresados.");
    		break;
    	case 24:
    		mensaje=("El folio y el asiento s�lo deben contener n�meros. Por favor verifique los datos ingresados.");
    		break;
    	case 25:
    		mensaje=("La secuencia del folio no es v�lida. Por favor verifique los datos ingresados.");
    		break;
    	case 26:
    		mensaje=("El folio y el asiento no pueden ser ceros. Por favor verifique los datos ingresados.");
    		break;
    	case 27:
    		mensaje=("El d�gito verificador es incorrecto.  Por favor verifique los datos ingresados.");
    		break;
    	case 32:
    		mensaje=("El campo no puede ser espacios. Por favor verifique los datos ingresados.");
    		break;
    	case 33:
    		mensaje=("La clave alfanum�rica de la c�dula no corresponde con la provincia. Por favor verifique los datos ingresados.");
    		break;
    	case 34:
    		mensaje=("Este tipo de RUC no acepta pagos.");
    		break;
    	case 35:
    		mensaje=("El digito verificador  num�rico es diferente del digito verificador cadena");
    		break;
    	default:
    		throw new ErrorEnEjecucionExcepcion(0,"Error en ejecuci�n");
    	
    	}
    	
    		return mensaje;
    }
    protected static void lanzaExcepcion(int codigoError) throws ErrorEnEjecucionExcepcion{
    	String mensajeError;
    	mensajeError=mensajeDeError(codigoError);
    	throw new ErrorEnEjecucionExcepcion(codigoError, mensajeError);
    	
    	
    }
}
