package com.bgeneral.canales.validadigito;

import static java.lang.Integer.parseInt;
/**ValidaServicios: Valida los formatos y los digitos verificadores de los servicios
 * publicos como IDAAN, CW Telefonia Fija, Union Fenosa, y cuentas genericas.
 * 
 * @author brrodriguez
 *
 */
class ValidaServicios {
	/**sbrIDAAN: Valida formato de la cuenta Idaan.
	 * 
	 * @param valor
	 * @param longMax
	 * @return True o Excepcion.
	 */
	protected static boolean sbrIDAAN(String valor, int longMax)
	    {
	        long VTCuenta;
	        boolean error=false, correcto=true;
	        int codigoError=0;
	        
	        if (((valor.trim()).length()) != longMax) {
	            codigoError=3;
	            error=true;
	        }

	        else if (!(ValidaValor.esNumerico(valor.substring(0, valor.length()-1)))) {
	        	 codigoError=3;
	             error=true;
	            
	        } 
	       else if(parseInt(valor.substring(0, valor.length()-1))==0){
	    	   //La cuenta es cero
	                 codigoError=4;
	                 error=true;
	        }

	       else if (!(validaIdaan((valor.substring(0, valor.length()-1).trim()), valor.substring(valor.length()-1, valor.length())))) {
	            //VALIDA EL DIGITO VERIFICADOR IDAAN
	        	 codigoError=27;
	             error=true;
	        }
	        
	        if(error){
	        	MensajesDeError.lanzaExcepcion(codigoError);
	        }
	        return correcto;
	    }

/**
 * validaIdaan:Compara la cuenta contra el digito verificador idaan.
 * @param pContrato
 * @param pDigito
 * @return True o Excepcion.
 */
	    private static boolean validaIdaan(String pContrato, String pDigito)
	    {
	        String VTContrato, wDigito;
	        int wFactor = 2, wInd;
	        long wSuma = 0;
	        boolean estado;

	        VTContrato = (pContrato.substring(0, pContrato.length()).trim());
	        for (wInd = pContrato.length()-1; wInd >= 0; wInd--) {
	            wSuma = wSuma + parseInt(VTContrato.substring(wInd, wInd + 1)) * wFactor;
	            if (wFactor == 7) {
	                wFactor = 2;
	            } else {
	                wFactor++;
	            }
	        }
	        wDigito = Integer.toString((int) (11 - (wSuma % 11))).trim();
	        switch (wDigito) {
	            case "11":
	                wDigito = "0";
	                break;
	            case "10":
	                wDigito = "K";
	                break;
	        }
	        estado = pDigito.trim().equals(wDigito.trim());

	        return estado;

	    }
/**sbrCW_TF: Valida formato de cuenta cable and wireless(telefono fijo).
 * @param valor
 * @param largoMax
 * @return True o Excepcion.
 */
	    protected static boolean sbrCW_TF(String valor, int largoMax)
	    {
	    	boolean error=false, correcto=true;
	    	int codigoError=0;
	        if ((valor.substring(0, largoMax).equals(ValidaValor.cadenaDinamica('0', largoMax)))) {
	        	codigoError=3;
	            error=true;
	        }
	        else if (((valor.trim().length()) != largoMax)
	                || !(ValidaValor.esNumerico(valor))) {
	        	codigoError=3;
	            error=true;
	        }
	        else if (!(chequeaDigito(valor, "03"))) {
	            //VALIDA EL DIGITO VERIFICADOR CW
	        	codigoError=27;
	            error=true;
	        }
	        
	        if(error){
	        	MensajesDeError.lanzaExcepcion(codigoError);
	        }
	        return correcto;
	    }
/**sbrUFenosa: Valida formato de la cuenta en gas natural fenosa(union fenosa, edemeth edechi). 
 * @param valor
 * @param largoMax
 * @return True o Excepcion.
 */
	    protected static boolean sbrUFenosa(String valor, int largoMax)
	    {
	    	boolean error=false, correcto=true;
	    	int codigoError=0;
	        if ((valor.substring(0, largoMax).equals(ValidaValor.cadenaDinamica('0', largoMax)))) {
	        	codigoError=3;
	            error=true;
	        }
	        else if (valor.substring(0, 1).equals("0")) {
	        	codigoError=3;
	            error=true;
	        }
	        else  if (((valor.trim().length()) != largoMax)
	                || !(ValidaValor.esNumerico(valor))
	                || (valor.contains("."))
	                || (valor.contains(","))
	                || (valor.contains("-"))
	                || (valor.contains("$"))
	                || (valor.contains("+"))) {
	        	codigoError=3;
	            error=true;
	        }
	        if(error){
	        	MensajesDeError.lanzaExcepcion(codigoError);
	        }
	        return correcto;
	    }
	    /**ChequeaDigito: Valida digito verificador CW.
	     * @param wCuenta
	     * @param wTipo
	     * @return True o Excepcion.
	     */
	    private static boolean chequeaDigito(String wCuenta, String wTipo)
	    {
	        int VTLongServ = 0, VTModuloServ = 0, VTModulo, VTSum=0, VTSuma, VTValor, VTCero_Ascii, VTVariable, VTNum;
	        int j=0, i, VTInd;
	        boolean estado;
	        String VTPesosServ = "", VTNumero = "";
	        long VTLong, VTDigito;
	        switch (wTipo) {
	            case "03"://C&W
	                VTLongServ = 13;
	                VTPesosServ = "3210987654321";
	                VTModuloServ = 11;
	                break;
	          
	                default:
	                	MensajesDeError.lanzaExcepcion(0);
	                	break;

	        }

	        if (wCuenta.length() < VTLongServ) {
	            estado = false;
	            return estado;
	        }

	        
	        if (wTipo.equals("03")) {//C&W 
	            for (i = (VTLongServ - (wCuenta.length()) + 1); i <= VTLongServ - 1; i++) {
	                VTSum = VTSum + (parseInt(wCuenta.substring(j, j + 1)) * (VTLongServ - i + 1));
	                j++;
	            }
	        } 
	        VTModulo = VTSum % VTModuloServ;
	        if (VTModulo >= (VTModuloServ - 9)) {
	            VTModulo = VTModuloServ - VTModulo;
	        } else {
	            VTModulo = 0;
	        }

	        if (VTModulo != parseInt(wCuenta.substring(VTLongServ - 1, VTLongServ))) {
	            estado = false;
	        } else {
	            estado = true;
	        }

	        return estado;

	    }
	    /**sbrValidaGenerico: Valida cuentas genericas segun longitud.
	     * @param valor
	     * @param formato
	     * @return True o Excepcion.
	     */
	    protected static boolean sbrValidaGenerico(String valor, String formato)
	    {
	    	boolean error=false, correcto=true;
	    	int codigoError=0;
	        if (ValidaValor.esNumerico(formato)) {
	            if (ValidaValor.Val(valor) == 0) {
	            	codigoError=4;
	                error=false;
	            }
	        } else {
	            if ((valor.trim().length()) < 1) {
	                codigoError=32;
	                error=false;
	            }
	        }
	        if(error){
	        	MensajesDeError.lanzaExcepcion(codigoError);
	        }
	        return correcto;
	    }
}
