package com.bgeneral.canales.validadigito;

import static java.lang.Integer.parseInt;
/**ValidaFormatoCedula: Clase encargada de validar que la cedula tenga un formato correcto.
 * 
 * @author brrodriguez
 *
 */
class ValidaFormatoCedula {
	/**sbrValida_Cedula: Recibe la cedula y la valida.
	 * 
	 * @param valor Cedula
	 * @param largoMax Largo maximo de la cedula
	 * @return Retorna true si la cedula tiene el formato correcto, o genera una excepcion
	 */
	protected static boolean sbrValida_Cedula(String valor, int largoMax)
    {
        boolean error=false, correcta=true;
        int codigoError=0;
        if ((valor.trim().length()) < largoMax) {
        	codigoError=19;
            error=true;
            
        }
        else if ((parseInt(valor.substring(0, 2))) > 10) {
        	codigoError=20;
            error=true;
        }
        else if (!(valor.substring(2, 4).equals("  "))
                && !(valor.substring(2, 4).equals("NT"))
                && !(valor.substring(2, 4).equals("E "))
                && !(valor.substring(2, 4).equals("PE"))
                && !(valor.substring(2, 4).equals("PI"))
                && !(valor.substring(2, 4).equals("N "))
                && !(valor.substring(2, 4).equals("AV"))) {
        	codigoError=21;
            error=true;
        }
        else if ((valor.substring(2, 5).equals("NT"))
                || (valor.substring(2, 5).equals("E "))
                || (valor.substring(2, 5).equals("N "))
                || (valor.substring(2, 5).equals("PE"))
                && (parseInt(valor.substring(0, 2)) != 0) &&
                (parseInt(valor.substring(0, 2)) != 5)) {
            
            codigoError=22;
            error=true;
        }

        else if ((valor.substring(4, 13)).trim().length() < 9) {
        	codigoError=23;
            error=true;
        }
        else if (((parseInt(valor.substring(0, 2))) == 0) && (valor.substring(2, 4)).equals("  ")) {
        	codigoError=33;
            error=true;;
        }

        else if (!(ValidaValor.esNumerico(valor.substring(4, 13)))) {
        	codigoError=24;
            error=true;;
        }
        else if (((parseInt(valor.substring(4, 8))) > 532) && (parseInt(valor.substring(4, 8)) < 700)) {
        	codigoError=25;
            error=true;
        }
        else if ((valor.substring(4, 8).equals("0000")) || (valor.substring(8, 14)).equals("000000")) {
        	codigoError=26;
            error=true;
        }
        
        if(error){
        	MensajesDeError.lanzaExcepcion(codigoError);
        }
        return correcta;
    }

}
