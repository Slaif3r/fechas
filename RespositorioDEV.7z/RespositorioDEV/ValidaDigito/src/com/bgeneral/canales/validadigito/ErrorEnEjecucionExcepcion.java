package com.bgeneral.canales.validadigito;

public class ErrorEnEjecucionExcepcion  extends RuntimeException{
/**
 * ErrorEnEjecucionExcepcion:
 * Si las validaciones tienen algun incovenniente, se detendra la ejecucion
 * y se lanzara un codigo de error con su descripcion.
 * @author brrodriguez
 */
private int codigoError;
/**ErrorEnEjecucionExcepcion: Lanza el codigo y el mensaje.
 * 
 * @param codigo Codigo de error.
 * @param mensaje Mensaje personalizado.
 */
public ErrorEnEjecucionExcepcion(int codigo, String mensaje){
	super(mensaje);
	this.codigoError=codigo;
}
/**getCodigoError: Obtienes el codigo de error.
 * 
 * @return Retorna el codigo de error.
 */
public int getCodigoError(){
	return this.codigoError;
}
}
