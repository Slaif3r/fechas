/*
**************************************************************************
*                                                                        *
*    ARCHIVO:         validarDigito.jar                                  *
*    NOMBRE LOGICO:   validarDigito.java                                 *
*    PRODUCTO:      ***                                                  *
*                                                                        *
* ********************************************************************** *
*                                                                        *
*                     IMPORTANTE                                         *
* Este programa fue disenado por Banco General, S.A., y esta protegido   *
* por los derechos de propiedad intelectual.  Su uso no autorizado queda *
* expresamente prohibido de acuerdo a la legislacion vigente, asi como   *
* obtener una copia (total o parcial) para fines ajenos al banco, sin el *
* consentimiento de la Vice Presidencia Ejecutiva del Banco General, S.A.*
*                                                                        *
* ********************************************************************** *
*                                                                        * 
*                          PROPOSITO                                     *
* Clase encargada de validar el digito Verificador, y el formato de      *
* las cuentas Movistar, CW(Telefono Fijo), Gas Natural Fenosa,           *
* IDAAN, Inmueble, RUC en sus diferentes formatos.                       *
* Extraido de clsValidar.cls                                             *
*                                                                        *
*                                                                        *
* ************************** MODIFICACIONES  *************************** *
*                                                                        *
* FECHA           AUTOR                RAZON                             *
* 09/06/2016    Brayan Rodriguez      Emisi�n Inicial                    *
* 05/07/2016    Brayan Rodriguez      Refactorizaci�n                    *
*                                                                        *
* ********************************************************************** *
*/
package com.bgeneral.canales.validadigito;


import static java.lang.Integer.parseInt;


/**ValidaDigito.java:
 * Esta clase se encarga de recibir los parametros para validar los diferentes contratos.
 * @author brrodriguez
 */
public class ValidaDigito {   

    
    private ValidaDigito(){}
    /**
     * @author brrodriguez
    * @param mvarFormato Formato de la mascara
    * @param UsaDV Indica Si la cuenta, cedula, finca utiliza Digito verificador(S,N)
    * @param mvarTipoLong Tipo de longitud cuenta, cedula, finca si es Variable(V) o Fija(F)
    * @param mvarLargoMin Largo Minimo
    * @param mvarLargoMax Largo Maximo
    * @param mvarTipoValidacion Tipo de validacion del contrato
    * @param mvarTipoColector Numero del Colector
    * @param mvarCodigoMsk Codigo de la Mascara
    * @param mvarValor Cuenta, Cedula, Finca a Validar
    * @param mvarDV Digito Verificador Numerico
    * @param mvarDVCHAR Digito Verificador cadena
    * @return Retorna true si fue exitosa la validacion, o una excepcion si hay errores
    * @throws ErrorEnEjecucionExcepcion Envia una excepcion se genera un error */
    public static boolean ValidarContrato(String mvarFormato, String UsaDV, String mvarTipoLong, int mvarLargoMin, int mvarLargoMax,
    		                           String mvarTipoValidacion, String mvarTipoColector, int mvarCodigoMsk, String mvarValor,
    		                           int mvarDV,String mvarDVCHAR) throws ErrorEnEjecucionExcepcion
  {//VALIDA LA LONGITUD DEL CONTRATO Y LAS MASCARAS, INICIA LAS COMPROBACIONES
  boolean estado=false;
    	
    	if (ValidaMascara(mvarValor, mvarLargoMin, mvarLargoMax, mvarTipoLong,mvarFormato, UsaDV, mvarDV, mvarDVCHAR )){
        
        switch (mvarTipoValidacion) {
        //VALIDACIONES
            case "02"://IDAAN
                estado=ValidaServicios.sbrIDAAN(mvarValor,mvarLargoMax);
                break;
            case "03": //C&W - TELEFONIA FIJA
                estado=ValidaServicios.sbrCW_TF(mvarValor,mvarLargoMax);
                break;
            case "04": //UNION FENOSA (EDEMET-EDECHI)
                estado=ValidaServicios.sbrUFenosa(mvarValor, mvarLargoMax);
                break;
           /* case "05": //ELEKTRA NORESTE, se esta validando Generico
               break;*/
            case "06": //INMUEBLE CON DV
            	estado=ValidaInmueble.sbrInmuebleDV(mvarValor, mvarLargoMin, mvarLargoMax, mvarTipoValidacion, mvarDV);
            	break;
            /*case "07": CEDULA CON DV, Se esta validando en la opcion 14
               break;*/
            case "08"://CEDULA SIN DV
                estado=ValidaFormatoCedula.sbrValida_Cedula(mvarValor,  mvarLargoMax); 
                break;
            case "09": //AMERICAN EXPRESS
                //Esto se valida en COBIS
                break;
           /* case "10": //BELLSOUTH - CELULAR(Movistar), se esta validando en Generico
               break;*/
            case "11": //FINANZAS GENERALES
                //Esto se valida en COBIS
                break;
            case "12": //RUC JURIDICO
                estado=ValidaDigitoImpuestos.sbrImpuestosConRUC(0,mvarValor,mvarDVCHAR, mvarLargoMax);
                break;
            case "13": //RUC NT
                estado=ValidaDigitoImpuestos.sbrImpuestosConRUC(1,mvarValor,mvarDVCHAR, mvarLargoMax);
                break;
            case "14": //PERSONA NATURAL
                estado=ValidaDigitoImpuestos.sbrImpuestosConRUC(2,mvarValor,mvarDVCHAR, mvarLargoMax);
                break;
            case "15": //INMUEBLE FORMATO CUI 10-011
                estado=ValidaInmueble.sbrInmuebleDV(mvarValor, mvarLargoMin, mvarLargoMax, mvarTipoValidacion, mvarDV);
                break;
            case "17": //RUC (FOLIO REAL ELECTRONICO) 
                estado=ValidaDigitoImpuestos.sbrImpuestosConRUC(3,mvarValor,mvarDVCHAR, mvarLargoMax);
                break;
            default://Valida cualquier tipo que no esta dentro de las categorias
                estado=ValidaServicios.sbrValidaGenerico(mvarValor, mvarFormato);
        }
        }
    	else
    	{
    		MensajesDeError.lanzaExcepcion(0);
    	}
    	return estado;
    }
    
    /**
     * validaMascara: Encargado de validar el contrato contra la mascara.
     * @param Valor Cuenta, Cedula, Finca
     * @param largoMin Longitud Maxima del valor
     * @param largoMax Longitud Minima del valor
     * @param tipoLongitud Variable(V), o Fija(F)
     * @param Formato Formato de la Mascara
     * @param usaDV Utiliza digito Verificador
     * @param digitoVerificador Digito Verificador Numerico
     * @param dvChar Digito Verificador Cadena
     * @return true si la validacion de la mascara es correcta
     * @throws ErrorEnEjecucionExcepcion
     */

    private static boolean ValidaMascara(String Valor, int largoMin, int largoMax,String tipoLongitud, String Formato, String usaDV,int digitoVerificador, String dvChar) throws ErrorEnEjecucionExcepcion{
    	int wInd1=1, wInd2, wTope, codigoError=0;
        boolean wHuboError=false, mascaraCorrecta=false;
        
       

         
        if ("F".equals(tipoLongitud))// LONGITUD FIJA
        {
            if (Valor.length() != largoMax) {
                codigoError=1;
                MensajesDeError.lanzaExcepcion(codigoError);
                
                
            }
        } else if("V".equals(tipoLongitud))//LONGITUD VARIABLE
        {

            if ((Valor.length() < largoMin) || (Valor.length() > largoMax)) {
            	 codigoError=1;
            	 MensajesDeError.lanzaExcepcion(codigoError);
                

            }
        }
        else{
        	 codigoError=0;
        	 MensajesDeError.lanzaExcepcion(codigoError);
        }
        
        if("S".equals(usaDV)){
        	if(!(digitoVerificador==parseInt(dvChar))){
        		codigoError=35;
        		MensajesDeError.lanzaExcepcion(codigoError);
        	}
        }

       if ("V".equals(tipoLongitud)) {
            wTope = Valor.length();
        } else //mvarTipoLong="F"
        {
            wTope = Formato.length();
        }

    
        for (wInd2 = 1; wInd2 <= wTope; wInd2++) {//VALIDA MASCARAS CONTRA VALOR

            switch (Formato.substring((wInd2 - 1), wInd2)) {
                case "9":
                    if (ValidaValor.esNumerico(Valor.substring(wInd1 - 1, wInd1))) {
                        wInd1++;
                    } else {
                        wHuboError = true;
                        
                    }
                    break;

                case "A":
                    if ((Character.toUpperCase(Valor.charAt(wInd1 - 1)) >= 'A')
                            && (Character.toUpperCase(Valor.charAt(wInd1 - 1)) <= 'Z')
                            || ((Valor.charAt(wInd1 - 1)) == ' ')) {
                        wInd1++;
                    } else {
                        wHuboError = true;
                    
                    }
                    break;

                case "B":
                    if ((Character.toUpperCase(Valor.charAt(wInd1 - 1)) >= 'A')
                            && (Character.toUpperCase(Valor.charAt(wInd1 - 1)) <= 'Z')) {
                        wInd1++;
                    } else {
                        wHuboError = true;
                        
                    }
                    break;

                case "X":
                    if ((Character.toUpperCase(Valor.charAt(wInd1 - 1)) >= 'A')
                            && (Character.toUpperCase(Valor.charAt(wInd1 - 1)) <= 'Z')
                            || ((Valor.charAt(wInd1 - 1)) == ' ')
                            || (ValidaValor.esNumerico(Valor.substring(wInd1 - 1, wInd1)))) {
                        wInd1++;
                    } else {
                        wHuboError =true;
                        
                    }
                    break;

                case "Z":
                    if ((Character.toUpperCase(Valor.charAt(wInd1 - 1)) >= 'A')
                            && (Character.toUpperCase(Valor.charAt(wInd1 - 1)) <= 'Z')
                            || (ValidaValor.esNumerico(Valor.substring(wInd2 - 1, wInd1)))) {
                        wInd1++;
                    } else {
                        wHuboError = true;
                        
                    }
                    break;

                case "L":
                    wInd1++;
                    break;

                case "-":

                    break;

            }
            if (wHuboError){
            	codigoError=2;
            	MensajesDeError.lanzaExcepcion(codigoError);
            }

        }
        mascaraCorrecta=true;
return mascaraCorrecta;
    }

   
   

    
   
   


    

   
   
  

   
   
}
