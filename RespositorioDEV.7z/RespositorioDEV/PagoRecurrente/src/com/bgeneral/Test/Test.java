/**************************************************************************/
/*    ARCHIVO: Test.java                                                  */  
/*    NOMBRE LOGICO: Test                                                 */
/*    PRODUCTO: Banca en Linea                                            */
/**************************************************************************/
/*                     IMPORTANTE                                         */
/* Este programa fue disenado por Banco General, S.A., y esta protegido   */
/* por los derechos de propiedad intelectual.  Su uso no autorizado queda */
/* expresamente prohibido de acuerdo a la legislacion vigente, asi como   */
/* obtener una copia (total o parcial) para fines ajenos al banco, sin el */
/* consentimiento de la Vice Presidencia Ejecutiva del Banco General, S.A.*/
/**************************************************************************/
/*                          PROPOSITO                                     */
/*Aplicacion que permite calcular la fecha de los pagos recurrentes       */
/*de acuerdo al modelo especificado por el cliente.                       */ 
/****************************  MODIFICACIONES  ****************************/
/*   FECHA               AUTOR                  RAZON                     */
/* 10-6-2016	Christopher Mitchell	Adecuaciones t�cnicas             */
/* 28-7-2016	Christopher Mitchell	Cambio de nombre a paquete        */
/**************************************************************************/

package com.bgeneral.Test;

import java.time.LocalDate; 
import com.bgeneral.canales.pagorecurrente.PagoRecurrente;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalDate fecha_actual = LocalDate.of(2017,07,12); //formato ~ a�o, mes, dia
		int num_pagos =5;
		String num_dias = "2";

		try{
			System.out.println(PagoRecurrente.obtener_fecha_pagos(fecha_actual,num_pagos,num_dias));
		}
		catch (Exception e){
			e.printStackTrace();
		}
	}

}
