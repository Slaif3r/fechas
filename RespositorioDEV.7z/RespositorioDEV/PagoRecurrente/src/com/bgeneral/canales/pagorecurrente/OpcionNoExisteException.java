package com.bgeneral.canales.pagorecurrente;

public class OpcionNoExisteException extends Exception{
	
	public OpcionNoExisteException(String mensaje) { 
		
		super(mensaje); 
		
		}
}
