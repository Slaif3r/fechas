package com.bgeneral.canales.pagorecurrente;

import java.time.LocalDate;

public class UtilidadesRangoPago {
	
	private static LocalDate calcularrango (LocalDate fecha_inicial){
		LocalDate  fecha_actual = null;
			
	 // si est� entre rango 10/25 
		if (fecha_inicial.getDayOfMonth() == 25 && fecha_inicial.lengthOfMonth() == 31) {
			fecha_actual = fecha_inicial.plusDays(16);
		}
		else if(fecha_inicial.getDayOfMonth() >= 15 ){fecha_actual = fecha_inicial.plusDays(15);}
			
		return fecha_actual;
	} 

}
