package prueba;
import com.bgeneral.canales.pagorecurrente.PagoRecurrente;


import java.time.LocalDate;

public class Prueba {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalDate fecha_actual = LocalDate.of(2017,07,15); //formato ~ a�o, mes, dia
		int num_pagos = 5;
		String num_dias = "2";

		try{
			System.out.println(PagoRecurrente.obtener_fecha_pagos(fecha_actual,num_pagos,num_dias));
		}
		catch (Exception e){
			e.printStackTrace();
		}
	}

}
