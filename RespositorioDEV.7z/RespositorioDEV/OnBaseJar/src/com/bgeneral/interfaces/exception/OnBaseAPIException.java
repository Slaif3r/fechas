/**
 * 
 */
package com.bgeneral.interfaces.exception;

import java.io.IOException;
import java.text.ParseException;

import Hyland.Unity.MaxConcurrentLicensesException;
import Hyland.Unity.UnityAPIException;

/**
 * @author jsoto
 *
 */
public class OnBaseAPIException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String mensaje="Ha Ocurrido un Error!";
	
	//Constructor.
	public OnBaseAPIException(){}
	
	public OnBaseAPIException(String mensaje){
		super(mensaje);
	}
	
	public OnBaseAPIException(UnityAPIException unityAPIException){
//		this.getMessage(unityAPIException);
		super(unityAPIException);
	}
	
	public OnBaseAPIException(MaxConcurrentLicensesException maxConcurrentLicense){
		super(maxConcurrentLicense);
	}
	
	public OnBaseAPIException(IOException ex){
		super(ex);
	}	
	
	public OnBaseAPIException(ParseException ex){
		super(ex);
	}
	
	
	public OnBaseAPIException(IllegalAccessException ex){
		super(ex);
	}
	
	
	public OnBaseAPIException(InstantiationException ex){
		super(ex);
	}	
	
	public OnBaseAPIException(NullPointerException ex){
		super(ex);
	}
	
	public OnBaseAPIException(CloneNotSupportedException ex){
		super(ex);
	}
}
