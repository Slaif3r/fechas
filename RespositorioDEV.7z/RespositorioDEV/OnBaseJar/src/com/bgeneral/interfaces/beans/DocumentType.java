package com.bgeneral.interfaces.beans;

import java.io.Serializable;

public class DocumentType implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private long id;
	private String name;	
	private DocumentTypeGroup documentTypeGroup;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public DocumentTypeGroup getDocumentTypeGroup() {
		return documentTypeGroup;
	}

	public void setDocumentTypeGroup(DocumentTypeGroup documentTypeGroup) {
		this.documentTypeGroup = documentTypeGroup;
	}
	
	
	
	

}
