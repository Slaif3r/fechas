/**
 * 
 */
package com.bgeneral.interfaces.beans;

import java.io.InputStream;
import java.io.Serializable;

/**
 * @author jsoto
 *
 */
public class Imaging  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private PageData pageData;

	public PageData getPageData() {
		return pageData;
	}

	public void setPageData(PageData pageData) {
		this.pageData = pageData;
	}
	
	

}
