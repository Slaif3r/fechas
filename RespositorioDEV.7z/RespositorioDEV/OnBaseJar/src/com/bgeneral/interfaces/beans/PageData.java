/**
 * 
 */
package com.bgeneral.interfaces.beans;

import java.io.InputStream;
import java.io.Serializable;

/**
 * @author jsoto
 *
 */
public class PageData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	private InputStream cheque;
	private String extension;
	
	
	public InputStream getCheque() {
		return cheque;
	}
	public void setCheque(InputStream cheque) {
		this.cheque = cheque;
	}
	public String getExtension() {
		return extension;
	}
	public void setExtension(String extension) {
		this.extension = extension;
	}
	
}
