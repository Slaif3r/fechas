/**
 * 
 */
package com.bgeneral.interfaces.beans;

import java.io.Serializable;

/**
 * @author jsoto
 *
 */
public class Revision implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	

}
