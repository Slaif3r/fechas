/**
 * 
 */
package com.bgeneral.interfaces.beans;

import java.io.Serializable;

/**
 * @author jsoto
 *
 */
public class Document implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private long id;
	private String name;
	private DocumentType documentType;
	private String cuentaAbuscar;	//numero de cuenta que se utiliza para buscar documentos.
	private long latestAllowedRevisionID;
	private Imaging imaging;
	private Rendition rendition;
	
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public DocumentType getDocumentType() {
		return documentType;
	}
	public void setDocumentType(DocumentType documentType) {
		this.documentType = documentType;
	}
	public String getCuentaAbuscar() {
		return cuentaAbuscar;
	}
	public void setCuentaAbuscar(String cuentaAbuscar) {
		this.cuentaAbuscar = cuentaAbuscar;
	}
	public Imaging getImaging() {
		return imaging;
	}
	public void setImaging(Imaging imaging) {
		this.imaging = imaging;
	}
	public long getLatestAllowedRevisionID() {
		return latestAllowedRevisionID;
	}
	public void setLatestAllowedRevisionID(long latestAllowedRevisionID) {
		this.latestAllowedRevisionID = latestAllowedRevisionID;
	}
	public Rendition getRendition() {
		return rendition;
	}
	public void setRendition(Rendition rendition) {
		this.rendition = rendition;
	}
	
	
	

	
}
