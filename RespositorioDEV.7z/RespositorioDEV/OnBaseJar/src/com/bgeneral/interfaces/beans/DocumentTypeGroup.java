/**
 * 
 */
package com.bgeneral.interfaces.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author jsoto
 *
 */
public class DocumentTypeGroup implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private long id;
	private String name;
	private List<DocumentType> documentTypeList = new ArrayList<>();
	
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<DocumentType> getDocumentTypeList() {
		return documentTypeList;
	}
	public void setDocumentTypeList(List<DocumentType> documentTypeList) {
		this.documentTypeList = documentTypeList;
	}
	
	
	
	
}
