/**
 * 
 */
package com.bgeneral.interfaces.beans;

import java.io.Serializable;
import java.util.Date;

/**
 * @author jsoto
 *
 */
public class Rendition implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String comment;
	private Date creationDate;
	private long getId;
	private Imaging imaging;
	private String name;
	private long numberOfPages;
	private Revision revision;
	
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public Date getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}
	public long getGetId() {
		return getId;
	}
	public void setGetId(long getId) {
		this.getId = getId;
	}
	public Imaging getImaging() {
		return imaging;
	}
	public void setImaging(Imaging imaging) {
		this.imaging = imaging;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getNumberOfPages() {
		return numberOfPages;
	}
	public void setNumberOfPages(long numberOfPages) {
		this.numberOfPages = numberOfPages;
	}
	public Revision getRevision() {
		return revision;
	}
	public void setRevision(Revision revision) {
		this.revision = revision;
	}
	
	
	

}
