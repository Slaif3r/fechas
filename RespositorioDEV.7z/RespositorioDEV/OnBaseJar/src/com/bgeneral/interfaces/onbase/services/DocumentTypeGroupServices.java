package com.bgeneral.interfaces.onbase.services;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import com.bgeneral.interfaces.beans.Connection;
import com.bgeneral.interfaces.connection.APIConnection;
import com.bgeneral.interfaces.exception.OnBaseAPIException;
import com.bgeneral.interfaces.onbase.utils.Mensajes;

import Hyland.Unity.Application;
import Hyland.Unity.Core;
import Hyland.Unity.DocumentType;
import Hyland.Unity.DocumentTypeGroup;
import Hyland.Unity.DocumentTypeGroupList;
import Hyland.Unity.DocumentTypeList;
import Hyland.Unity.UnityAPIException;

public class DocumentTypeGroupServices {

	Connection conn = new Connection();
	DocumentTypeGroupList lista;
	public DocumentTypeGroupServices(Connection connection){
		
		this.conn = connection;
	}
	
	
	/**
	 * Retorna todos los tipos de documentos de un grupo en especifico por medio de la descripci�n.
	 * @param group: nombre o descripci�n del grupo de tipo de documentos por el cual deseamos filtrar.
	 * @return retorna una lista de tipo List<com.bgeneral.interfaces.beans.DocumentType>
	 * @throws OnBaseAPIException
	 */
	public List<com.bgeneral.interfaces.beans.DocumentType> getAllDocumentTypeByGroup(String group)
			throws OnBaseAPIException{
		
		
		
		APIConnection api = new APIConnection();
		Application app= null;
		List<com.bgeneral.interfaces.beans.DocumentType> listaDocumentType = new ArrayList<>();
		com.bgeneral.interfaces.beans.DocumentType documentType = new com.bgeneral.interfaces.beans.DocumentType();
		
		DocumentTypeGroupList docTypeGroupList = null;
		DocumentTypeGroup docTypeGroup = null;
		
		
		try{
			//verificamos si los parametros de la conexi�n existen.
			if(this.conn!= null){
				
				//realizamos la conexi�n.
				 app = api.openConnection(conn);
					
					//verificamos si esta hay conexi�n.
					if(app.getIsConnected()){						
						
						Core core = app.getCore();
						
						//obtenemos todos los grupos de tipos de documentos.
						docTypeGroupList = core.getDocumentTypeGroups();
						
						//filtramos la lista de grupos de tipo de documentos por el nombre.
						docTypeGroup = docTypeGroupList.Find(group);
						
						
						DocumentTypeList lista = docTypeGroup.getDocumentTypes();
						
																	
						for(DocumentType dt : lista){
							documentType = new com.bgeneral.interfaces.beans.DocumentType();
							
							documentType.setId(dt.getID());
							documentType.setName(dt.getName());
							
							listaDocumentType.add(documentType);
							
						}		
						
					}else{
						
						throw new OnBaseAPIException(Mensajes.ERROR_CONEXION);
						
					}
			}else{
				throw new OnBaseAPIException(Mensajes.ERROR_PARAMETROS_CONEXION);
				
			}	//termina condicion que verifica si los parametros de conexi�n existen.							
			
		}catch(UnityAPIException ex){			
			throw new OnBaseAPIException(ex);
			
		} catch(NullPointerException ex){				
			throw new OnBaseAPIException(ex);
			
		}
		finally{
			if(app != null && app.getIsConnected()){							
				if(api.closeConnection( app))
					throw new OnBaseAPIException(Mensajes.ERROR_CONEXION_CERRAR+ Calendar.getInstance().getTime());
			}
		}				
			
		return listaDocumentType;
		
	}
	
	/**
	 * M�todo de uso exclusivo para este JAR. Regresa una lista de tipos de documentos. Se buscan todos los grupos
	 * de tipos de documentos, luego se filtra por el nombre del grupo de tipo de documento y una vez obtenido el grupo 
	 * de tipo de documento se obtiene la lista de tipos de documentos.
	 * @param nameGroup: nombre o descripci�n del grupo de tipo de documentos por el cual vamos a buscar.
	 * @return retorna un objeto de tipo Hyland.Unity.DocumentTypeList.
	 * @throws OnBaseAPIException
	 */
	protected DocumentTypeList getAllDocumentTypeByGroupOnBase( String nameGroup)
			throws OnBaseAPIException{
		
//		DocumentTypeList lista = null;
		
		
		
			APIConnection api = new APIConnection();
			Application app= null;
			DocumentTypeGroupList lista = null;	
			DocumentTypeGroup docTypeGroup = null;
			DocumentTypeList docTypeList = null;
			try{
				//verificamos si los parametros de la conexi�n existen.
				if(this.conn!= null){
					
					//realizamos la conexi�n.
					 app = api.openConnection(conn);
						
						//verificamos si esta hay conexi�n.
						if(app.getIsConnected()){						
							Core core = app.getCore();
							
							//buscamos todos los gurpos de tipos de documentos.
							lista = core.getDocumentTypeGroups();
							
							//filtramos por el nombre del grupo.
							docTypeGroup = lista.Find(nameGroup);
							
							//obtenemos la lista de tipos de documentos.
							docTypeList = docTypeGroup.getDocumentTypes();
						}else{
							
							throw new OnBaseAPIException(Mensajes.ERROR_CONEXION);
							
						}
				}else{
					throw new OnBaseAPIException(Mensajes.ERROR_PARAMETROS_CONEXION);
					
				}	//termina condicion que verifica si los parametros de conexi�n existen.							
				
			}catch(UnityAPIException ex){			
				throw new OnBaseAPIException(ex);
				
			}catch(NullPointerException ex){				
				throw new OnBaseAPIException(ex);
				
			}
			finally{
				if(app != null && app.getIsConnected()){
					if(api.closeConnection( app))
						throw new OnBaseAPIException(Mensajes.ERROR_CONEXION_CERRAR + Calendar.getInstance().getTime());
				}
			}
			if(docTypeList == null)
				throw new OnBaseAPIException(Mensajes.ERROR_MSJ_getAllDocumentTypeByGroupOnBase);
			return docTypeList;
		
		
	
	
		
	}
	
	/**
	 * Metodo que obtiene todo los grupos de tipos de documentos.
	 * @return retorna una lista de tipo com.bgeneral.interfaces.beans.DocumentTypeGroup.
	 * @throws OnBaseAPIException
	 */
	public List<com.bgeneral.interfaces.beans.DocumentTypeGroup> getAllDocumentTypeGroup()
			throws OnBaseAPIException{
		
		List<com.bgeneral.interfaces.beans.DocumentTypeGroup> lista = new ArrayList<>();
		com.bgeneral.interfaces.beans.DocumentTypeGroup documentTypeGroup = new com.bgeneral.interfaces.beans.DocumentTypeGroup();
		APIConnection api = new APIConnection();
		Application app= null;
			
		
		try{
			//verificamos si los parametros de la conexi�n existen.
			if(this.conn!= null){
				
				//realizamos la conexi�n.
				 app = api.openConnection(conn);
					
					//verificamos si esta hay conexi�n.
					if(app.getIsConnected()){						
						Core core = app.getCore();
						
						for(DocumentTypeGroup d : core.getDocumentTypeGroups()){
							documentTypeGroup = new com.bgeneral.interfaces.beans.DocumentTypeGroup();
							
							documentTypeGroup.setId(d.getID());
							documentTypeGroup.setName(d.getName());
							
							lista.add(documentTypeGroup);
						}
					}else{
						
						throw new OnBaseAPIException(Mensajes.ERROR_CONEXION);
						
					}
			}else{
				throw new OnBaseAPIException(Mensajes.ERROR_PARAMETROS_CONEXION);
				
			}	//termina condicion que verifica si los parametros de conexi�n existen.							
			
		}catch(UnityAPIException ex){			
			throw new OnBaseAPIException(ex);
			
		}catch(NullPointerException ex){				
			throw new OnBaseAPIException(ex);
			
		}
		finally{
			if(app != null && app.getIsConnected()){			
				if(api.closeConnection( app))
					throw new OnBaseAPIException(Mensajes.ERROR_CONEXION_CERRAR+ Calendar.getInstance().getTime());
			}
		}
					
		
		return lista;
	}
	
	/**
	 * M�todo de uso exclusivo para este JAR. Obtiene todos los grupos de tipo de documentos.
	 * @return retorna una lista de tipo Hyland.Unity.DocumentTypeGroupList.
	 * @throws OnBaseAPIException
	 */
	protected DocumentTypeGroupList getAllDocumentTypeGroupOnBase()
			throws OnBaseAPIException{					
		
		APIConnection api = new APIConnection();
		Application app= null;
			
		
		try{
			//verificamos si los parametros de la conexi�n existen.
			if(this.conn!= null){
				
				//realizamos la conexi�n.
				 app = api.openConnection(conn);
					
					//verificamos si esta hay conexi�n.
					if(app.getIsConnected()){						
						Core core = app.getCore();
						
						lista = core.getDocumentTypeGroups();
					}else{
						
						throw new OnBaseAPIException(Mensajes.ERROR_CONEXION);
						
					}
			}else{
				throw new OnBaseAPIException(Mensajes.ERROR_PARAMETROS_CONEXION);
				
			}	//termina condicion que verifica si los parametros de conexi�n existen.							
			
		}catch(UnityAPIException ex){			
			throw new OnBaseAPIException(ex);
			
		}catch(NullPointerException ex){				
			throw new OnBaseAPIException(ex);
			
		}
		finally{
			if(app != null && app.getIsConnected()){
				if(api.closeConnection( app))
					throw new OnBaseAPIException(Mensajes.ERROR_CONEXION_CERRAR + Calendar.getInstance().getTime());
			}
		}
		
		return lista;
	}
	
	/**
	 * 
	 * Metodo que busca un grupo de tipo de documentos por id de grupo de tipo de documentos.
	 * @param id: id del grupo de tipo de documentos que deseamos buscar especificamente.
	 * @return retorna una lista de tipo com.bgeneral.interfaces.beans.DocumentTypeGroup
	 * @throws OnBaseAPIException
	 */
	public com.bgeneral.interfaces.beans.DocumentTypeGroup findDocumentTypeGroup( long id) 
			throws OnBaseAPIException{
						
		com.bgeneral.interfaces.beans.DocumentTypeGroup documentTypeGroup = new com.bgeneral.interfaces.beans.DocumentTypeGroup();
		
		try{
		
			this.lista = this.getAllDocumentTypeGroupOnBase();
		

		for(DocumentTypeGroup group : this.lista){
			
			if(id == group.getID()){
				documentTypeGroup.setId(group.getID());
				documentTypeGroup.setName(group.getName());
				
				break;
			}
						
		}

		}catch(UnityAPIException ex){			
			throw new OnBaseAPIException(ex);
			
		}catch(NullPointerException ex){				
			throw new OnBaseAPIException(ex);
			
		}
		
		return documentTypeGroup;
	}
	
	/**
	 * M�todo de uso exclusivo para este Jar. busca un grupo de tipo de documentos por el id.
	 * @param lista
	 * @param id
	 * @return
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 * @throws UnityAPIException
	 * @throws OnBaseAPIException
	 */
	protected DocumentTypeGroup findDocumentTypeGroupOnBase(  long id) 
			throws 	OnBaseAPIException{
				
		DocumentTypeGroup dtg = null;
		try{
			
				lista = this.getAllDocumentTypeGroupOnBase();
			
			dtg = lista.Find(id);		
			
		}catch(UnityAPIException ex){			
			throw new OnBaseAPIException(ex);
			
		}catch(NullPointerException ex){				
			throw new OnBaseAPIException(ex);
			
		}
		
		if(dtg == null)
			throw new OnBaseAPIException(Mensajes.ERROR_MSJ_findDocumentTypeGroupOnBase);
				
		return dtg;
	}
	
	/**
	 * Metodo que busca un objeto de tipo DocumentTypeGroup por medio de la descripci�n.
	 * @param lista
	 * @param descripcion
	 * @return
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 * @throws UnityAPIException
	 */
//	public com.bgeneral.interfaces.beans.DocumentTypeGroup findDocumentTypeGroup(  String descripcion) 
//			throws OnBaseAPIException{
//				
//		com.bgeneral.interfaces.beans.DocumentTypeGroup group = new com.bgeneral.interfaces.beans.DocumentTypeGroup();
//	
//		try{
//			
//				lista = this.getAllDocumentTypeGroupOnBase();
//			
//			
//			
//			for(DocumentTypeGroup g : lista){
//				
//				if(descripcion.equals(g.getName().toLowerCase())){					
//					
//					group.setId(g.getID());
//					group.setName(g.getName());
//					System.out.println("id: "+ group.getId()+ " name:"+ group.getName());
//					break;
//				}						
//				
//			}
//		}catch(UnityAPIException ex){			
//			throw new OnBaseAPIException(ex);
//			
//		}catch(NullPointerException ex){				
//			throw new OnBaseAPIException(ex);
//			
//		}		
//		return group;
//	}
	
	/**
	 * M�todo de uso exclusivo de este JAR. busca un objeto de tipo DocumentTypeGroup por medio de la descripci�n.
	 * @param lista
	 * @param descripcion
	 * @return
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 * @throws UnityAPIException
	 */
//	protected DocumentTypeGroup findDocumentTypeGroupOnBase(String descripcion) 
//			throws  OnBaseAPIException{
//				
//			DocumentTypeGroup dtg = null;			
//	
//			try{
//				
//					lista = this.getAllDocumentTypeGroupOnBase();
//				
//				dtg = lista.Find(descripcion);
//			}catch(UnityAPIException ex){			
//				throw new OnBaseAPIException(ex);
//				
//			}catch(NullPointerException ex){				
//				throw new OnBaseAPIException(ex);
//				
//			}
//			if(dtg == null)
//				throw new OnBaseAPIException(Mensajes.ERROR_MSJ_findDocumentTypeGroupOnBase2);
//		return dtg;
//	}
	
	/**
	 * metodo que busca en la lista de todos los grupos de tipo de documento un grupo de tipo
	 * de documento por su nombre o descripci�n.
	 * @param name
	 * @return
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 * @throws UnityAPIException
	 */
	public com.bgeneral.interfaces.beans.DocumentTypeGroup getDocumentTypeGrouByName(String name) 
			throws OnBaseAPIException{
		
		
		com.bgeneral.interfaces.beans.DocumentTypeGroup group = new com.bgeneral.interfaces.beans.DocumentTypeGroup();
		try{
			
				this.lista = this.getAllDocumentTypeGroupOnBase();
			
			
			for(DocumentTypeGroup g : this.lista){
				
				if(name.equals(g.getName())){
					
					group.setId(g.getID());
					group.setName(g.getName());
					
					break;
				}
				
			}
		}catch(UnityAPIException ex){			
			throw new OnBaseAPIException(ex);
			
		}catch(NullPointerException ex){				
			throw new OnBaseAPIException(ex);
			
		}
		
		return group;
	}
	
	/**
	 * M�todo de uso exclusivo de este JAR.  busca en la lista de todos los grupos de tipo de documento un grupo de tipo
	 * de documento por su nombre o descripci�n.
	 * @param name
	 * @return
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 * @throws UnityAPIException
	 */
	protected DocumentTypeGroup getDocumentTypeGrouByNameOnBase(String name) 
			throws  OnBaseAPIException{
		
		DocumentTypeGroup group = null;			
		try{
			
				this.lista = this.getAllDocumentTypeGroupOnBase();
			
			
			group = lista.Find(name);
		}catch(UnityAPIException ex){			
			throw new OnBaseAPIException(ex);
			
		}catch(NullPointerException ex){				
			throw new OnBaseAPIException(ex);
			
		}
		if(group == null)
			throw new OnBaseAPIException(Mensajes.ERROR_MSJ_getDocumentTypeGrouByNameOnBase);
		return group;
	}
	
	/**
	 * metodo que  busca en una lista de todos los grupos de tipo de documentos un grupo 
	 * especifico de documentos por id.
	 * @param id
	 * @return
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 * @throws UnityAPIException
	 */
//	@Deprecated
//	public com.bgeneral.interfaces.beans.DocumentTypeGroup getDocumentTypeGroupById( long id)
//			throws OnBaseAPIException{
//		
//		com.bgeneral.interfaces.beans.DocumentTypeGroup group = new com.bgeneral.interfaces.beans.DocumentTypeGroup();
//		try{
//			
//			lista = this.getAllDocumentTypeGroupOnBase();
//			
//			for(DocumentTypeGroup g : lista){
//				
//				if( id == g.getID()){
//					group.setId(g.getID());
//					group.setName(g.getName());
//					
//					break;
//				}
//				
//			}
//		}catch(UnityAPIException ex){			
//			throw new OnBaseAPIException(ex);
//			
//		}catch(NullPointerException ex){				
//			throw new OnBaseAPIException(ex);
//			
//		}
//		return group;
//		
//	}
//	
//	/**
//	 * M�todo que nos devuelve un grupo de tipo de documentos. Este metodo devuelve un objeto DocumentTypeGroup del API
//	 * de OnBase.
//	 * @param id: long que representa el grupo de tipo de documento que deseamos buscar.
//	 * @return
//	 * @throws OnBaseAPIException
//	 */
//	@Deprecated
//	protected DocumentTypeGroup getDocumentTypeGroupByIdOnBase( long id) 
//			throws OnBaseAPIException{
//		
//		DocumentTypeGroup group=null;
//		
//		try{
//			
//			
//				this.lista = this.getAllDocumentTypeGroupOnBase();
//			
//			
//			group = lista.Find(id);
//			
//		}catch(UnityAPIException ex){			
//			throw new OnBaseAPIException(ex);
//			
//		}catch(NullPointerException ex){				
//			throw new OnBaseAPIException(ex);
//			
//		}
//		if(group == null)
//			throw new OnBaseAPIException(Mensajes.ERROR_MSJ_getDocumentTypeGroupByIdOnBase);
//		return group;
//		
//	}
	
}
