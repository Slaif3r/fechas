/**
 * 
 */
package com.bgeneral.interfaces.onbase.services;



import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.bgeneral.interfaces.beans.Connection;
import com.bgeneral.interfaces.connection.APIConnection;
import com.bgeneral.interfaces.exception.OnBaseAPIException;
import com.bgeneral.interfaces.onbase.utils.MappingBeans;
import com.bgeneral.interfaces.onbase.utils.Mensajes;

import Hyland.Unity.Application;
import Hyland.Unity.Core;
import Hyland.Unity.CustomQuery;
import Hyland.Unity.Document;
import Hyland.Unity.DocumentList;
import Hyland.Unity.DocumentQuery;
import Hyland.Unity.DocumentType;
import Hyland.Unity.DocumentTypeGroup;
import Hyland.Unity.DocumentTypeGroupList;
import Hyland.Unity.DocumentTypeList;
import Hyland.Unity.EditableKeywordRecord;
import Hyland.Unity.Keyword;
import Hyland.Unity.KeywordModifier;
import Hyland.Unity.KeywordRecord;
import Hyland.Unity.KeywordRecordType;
import Hyland.Unity.KeywordRecordTypeList;
import Hyland.Unity.KeywordType;
import Hyland.Unity.KeywordTypeList;
import Hyland.Unity.PageData;
import Hyland.Unity.PageDataList;
import Hyland.Unity.PageRangeSet;
import Hyland.Unity.QueryKeywordRecord;
import Hyland.Unity.Rendition;
import Hyland.Unity.Retrieval;
import Hyland.Unity.UnityAPIException;

/**
 * @author jsoto
 *
 */
public class DocumentServices extends MappingBeans {

	
	Connection conn = new Connection();
	
	public DocumentServices(Connection connection){
		this.conn = connection;
	}
	
	
	/**
	 * M�todo que retorna una lista de documentos filtrados por el id de tipo de documento.	 
	 * @param idDocumentType: id del tipo de documento que vamos a buscar. Con este id  buscamos la informaci�n
	 *  del tipo de documento (documentType) y se arma el query.	 
	 * @param maxDoc: n�mero maximo de documentos a regresar.
	 * @param tipoDocumentoBandera: Variable que nos indica el tipo de imagen  a devolver T = Text, P = PDF, I = Imagen y es la que se busca por defecto.
	 * @return: una lista de tipo com.bgeneral.interfaces.beans.Document
	 * @throws OnBaseAPIException 
	 */
	public List<com.bgeneral.interfaces.beans.Document> getDocumentsByIdDocumentType(long idDocumentType,  long maxDoc, String tipoDocumentoBandera)
			throws OnBaseAPIException{
				
			APIConnection api = new APIConnection();
			Application app= null;
			List<com.bgeneral.interfaces.beans.Document> listaDocumentos = new ArrayList<>();
			com.bgeneral.interfaces.beans.Document documento = new com.bgeneral.interfaces.beans.Document();
			DocumentType documentType= null;
			DocumentTypeList lista = null;
			try{
				//verificamos si los parametros de la conexi�n existen.
				if(this.conn!= null){
					
					//realizamos la conexi�n.
					 app = api.openConnection(conn);
						
						//verificamos si esta hay conexi�n.
						if(app.getIsConnected()){
						
						Core core = app.getCore();
						
						//buscamos todos los tipos de documentos.
						lista = core.getDocumentTypes();
						
						//filtramos los tipos de documento por su id.
						documentType = lista.Find(idDocumentType);
						
						//Creaci�n del query.
						DocumentQuery query = core.CreateDocumentQuery();	
						
						//agregamos el tipo de documento encontrado.
						query.AddDocumentType(documentType);		

						//Ejecuci�n del query.
						DocumentList docs = query.Execute(maxDoc);
						
						listaDocumentos = mappingDocument(docs, core, tipoDocumentoBandera);						
						
						}else{
							
							throw new OnBaseAPIException(Mensajes.ERROR_CONEXION);
							
						}
				}else{
					throw new OnBaseAPIException(Mensajes.ERROR_PARAMETROS_CONEXION);
					
				}	//termina condicion que verifica si los parametros de conexi�n existen.
				
			}catch(UnityAPIException ex){				
				throw new OnBaseAPIException(ex);
				
			} catch (InstantiationException e) {				
				throw new OnBaseAPIException(e);
				
			} catch (IllegalAccessException e) {				
					throw new OnBaseAPIException(e);
					
			} catch (IOException e) {
				throw new OnBaseAPIException(e);
				
			}catch(NullPointerException ex){				
				throw new OnBaseAPIException(ex);
				
			}
			finally{
				if(app != null && app.getIsConnected()){
					if(api.closeConnection( app))
						throw new OnBaseAPIException(Mensajes.ERROR_CONEXION_CERRAR+ Calendar.getInstance().getTime());
				}
			}
					
		
		return listaDocumentos;
	}
	
	
	
	
	/**
	 * M�todo que busca todo los documento basandose en el id del grupo de tipo de documento.
	 * @param idgroup : id del grupo de tipo de documento por el cual vamos a buscar.
	 * @param maxDoc:  n�mero maximo de documentos a regresar.
	 * @param tipoDocumentoBandera: Variable que nos indica el tipo de imagen  a devolver T = Text, P = PDF, I = Imagen y es la que se busca por defecto.
	 * @return: retorna una lista de documentos de tipo com.bgeneral.interfaces.beans.Document
	 * @throws OnBaseAPIException
	 */
	public List<com.bgeneral.interfaces.beans.Document> getDocumentsByDocumentTypeGroup(long idgroup,  long maxDoc, String tipoDocumentoBandera )
			throws OnBaseAPIException{		
		
		APIConnection api = new APIConnection();
		Application app= null;
		List<com.bgeneral.interfaces.beans.Document> listaDocumentos = new ArrayList<>();
		com.bgeneral.interfaces.beans.Document documento = new com.bgeneral.interfaces.beans.Document();
		DocumentTypeGroup documentTypeGroup=null;
		DocumentTypeGroupList documentTypeGroupList=null;
		try{
			//verificamos si los parametros de la conexi�n existen.
			if(this.conn!= null){
				
				//realizamos la conexi�n.
				 app = api.openConnection(conn);
					
					//verificamos si esta hay conexi�n.
					if(app.getIsConnected()){
						
						Core core = app.getCore();
						
						//extraemos todos los grupo de tipos de documentos.
						documentTypeGroupList = core.getDocumentTypeGroups();
						
						//filtramos por el id del grupo de tipo de documento.
						documentTypeGroup = documentTypeGroupList.Find(idgroup);
						
						//Creaci�n del query.
						DocumentQuery query = core.CreateDocumentQuery();			
						
						query.AddDocumentTypeGroup(documentTypeGroup);	
						
						//Ejecuci�n del query.
						DocumentList docs = query.Execute(maxDoc);
						
						listaDocumentos = mappingDocument(docs, core,tipoDocumentoBandera);
						
					}else{
						
						throw new OnBaseAPIException(Mensajes.ERROR_CONEXION);
						
					}
			}else{
				throw new OnBaseAPIException(Mensajes.ERROR_PARAMETROS_CONEXION);
				
			}	//termina condicion que verifica si los parametros de conexi�n existen.
		
		}catch(UnityAPIException ex){			
			throw new OnBaseAPIException(ex);
			
		} catch (InstantiationException e) {		
			throw new OnBaseAPIException(e);
			
		} catch (IllegalAccessException e) {			
				throw new OnBaseAPIException(e);
				
		} catch (IOException e) {
			throw new OnBaseAPIException(e);
			
		}catch(NullPointerException ex){				
			throw new OnBaseAPIException(ex);
			
		}
		finally{
			if(app != null && app.getIsConnected()){
				if(api.closeConnection( app))
					throw new OnBaseAPIException(Mensajes.ERROR_CONEXION_CERRAR+ Calendar.getInstance().getTime());
				
			}
		}	
	
		return listaDocumentos;
	}
	
	
	
	
	
	/**
	 * M�todo que devuelve una lista de documentos por medio de la descripci�n o nombre del tipo de documento.
	 * El tipo de documento se filtra por medio del nombre.
	 * @param listaDocs: lista de todos los tipos de documentos.
	 * @param maxDocs : tama�o maximo de documentos a regresar.
	 * @param nameDocumentType: descripci�n o nombre del tipo de documento.
	 * @param tipoDocumentoBandera: Variable que nos indica el tipo de imagen  a devolver T = Text, P = PDF, I = Imagen y es la que se busca por defecto.
	 * @return  retorna una lista de tipo List<com.bgeneral.interfaces.beans.Document>
	 * @throws OnBaseAPIException
	 */
	public List<com.bgeneral.interfaces.beans.Document> getDocumentByNameOfDocumentType( String nameDocumentType, long maxDocs,  String tipoDocumentoBandera)
			throws OnBaseAPIException{
		
		APIConnection api = new APIConnection();
		Application app= null;
		List<com.bgeneral.interfaces.beans.Document> listaDocumentos = new ArrayList<>();
		com.bgeneral.interfaces.beans.Document documento = new com.bgeneral.interfaces.beans.Document();
		
		try{
			//verificamos si los parametros de la conexi�n existen.
			if(this.conn!= null){
				
				//realizamos la conexi�n.
				 app = api.openConnection(conn);
					
					//verificamos si esta hay conexi�n.
					if(app.getIsConnected()){						
					
						DocumentTypeServices dts = new DocumentTypeServices(conn);
						
						 //busca especificamente un tipo de documento por nombre.
						DocumentType documentType= dts.getDocumentTypeByNameOnBase( nameDocumentType);
						
						Core core = app.getCore();
						
						//Creamos el query.
						DocumentQuery query = core.CreateDocumentQuery();					
						query.AddDocumentType(documentType);

						//Ejecutamos.
						DocumentList docs = query.Execute(maxDocs);	
												
						listaDocumentos = mappingDocument(docs, core, tipoDocumentoBandera);
						
					}else{
						
						throw new OnBaseAPIException(Mensajes.ERROR_CONEXION);
						
					}
			}else{
				throw new OnBaseAPIException(Mensajes.ERROR_PARAMETROS_CONEXION);
				
			}	//termina condicion que verifica si los parametros de conexi�n existen.
		
		}catch(UnityAPIException ex){			
			throw new OnBaseAPIException(ex);
			
		} catch (InstantiationException e) {			
			throw new OnBaseAPIException(e);
			
		} catch (IllegalAccessException e) {			
				throw new OnBaseAPIException(e);
				
		} catch (IOException e) {
			throw new OnBaseAPIException(e);
			
		}catch(NullPointerException ex){				
			throw new OnBaseAPIException(ex);
			
		}
		finally{
			if(app != null && app.getIsConnected()){
				if(api.closeConnection( app))
					throw new OnBaseAPIException(Mensajes.ERROR_CONEXION_CERRAR+ Calendar.getInstance().getTime());
			}
		}
		return listaDocumentos;
	}
	

	/**
	 * busca un documento en especifico por su id dentro de una lista de documentos de tipo List<com.bgeneral.interfaces.beans.Document>.
	 * @param docs: lista de documentos de tipo List<com.bgeneral.interfaces.beans.Document>
	 * @param idDoc: id del documento que vamos a buscar.
	 * @return regresa un objeto de tipo com.bgeneral.interfaces.beans.Document
	 * @throws OnBaseAPIException
	 */
	public com.bgeneral.interfaces.beans.Document getDocumentById(List<com.bgeneral.interfaces.beans.Document> docs, long idDoc)
			throws OnBaseAPIException{
				
		com.bgeneral.interfaces.beans.Document documento = new com.bgeneral.interfaces.beans.Document();	
		
		try{
																
			//Recorremos la lista de documentos para buscar el documento deseado.
			for(com.bgeneral.interfaces.beans.Document doc : docs){
				
				if(idDoc == doc.getId()){					
					documento = new com.bgeneral.interfaces.beans.Document();
					
					documento.setId(doc.getId());
					documento.setName(doc.getName());
					documento.setLatestAllowedRevisionID(doc.getLatestAllowedRevisionID());
																		
					//Agregando info de la imagen al obj que se regresa.					
					documento.setImaging(doc.getImaging());
					documento.setRendition(doc.getRendition());	
					
					break;
				}	
			}	//cerramos el ciclo que busca el documento deseado.					
			
		}catch(UnityAPIException ex){			
			throw new OnBaseAPIException(ex);
			
		} catch(NullPointerException ex){				
			throw new OnBaseAPIException(ex);
			
		}
		
		return documento;
	}
	
	
	/**
	 * Metodo que regresa una lista de documentos basados en un rango de id de documentos.	 
	 * @param maxDocs: maximo de documentos a recuperar.
	 * @param startId: id de documento que inicia la b�squeda.
	 * @param endId id de documento que finaliza la b�squeda.
	 * @param tipoDocumentoBandera: Variable que nos indica el tipo de imagen  a devolver T = Text, P = PDF, I = Imagen y es la que se busca por defecto.
	 * @return retorna una lista de tipo List<com.bgeneral.interfaces.beans.Document>.
	 * @throws OnBaseAPIException
	 */
	public List<com.bgeneral.interfaces.beans.Document> getDocumentByRange(long maxDocs, long startId, long endId, String tipoDocumentoBandera)
			throws OnBaseAPIException{		
			
			APIConnection api = new APIConnection();
			Application app= null;
			List<com.bgeneral.interfaces.beans.Document> listaDocumentos = new ArrayList<>();
			com.bgeneral.interfaces.beans.Document documento = new com.bgeneral.interfaces.beans.Document();
			
			try{
				//verificamos si los parametros de la conexi�n existen.
				if(this.conn!= null){
					
					//realizamos la conexi�n.
					 app = api.openConnection(conn);
						
						//verificamos si esta hay conexi�n.
						if(app.getIsConnected()){						
							
							Core core = app.getCore();
							
							//Creamos query.
							DocumentQuery query = core.CreateDocumentQuery();					
							query.AddDocumentRange(startId, endId);
							
							//Ejecutamos.
							DocumentList docs = query.Execute(maxDocs);	
							
							listaDocumentos = mappingDocument(docs, core, tipoDocumentoBandera);
							
						}else{
							
							throw new OnBaseAPIException(Mensajes.ERROR_CONEXION);
							
						}
				}else{
					throw new OnBaseAPIException(Mensajes.ERROR_PARAMETROS_CONEXION);
					
				}	//termina condicion que verifica si los parametros de conexi�n existen.
				
			
			}catch(UnityAPIException ex){				
				throw new OnBaseAPIException(ex);
				
			} catch (InstantiationException e) {				
				throw new OnBaseAPIException(e);
				
			} catch (IllegalAccessException e) {				
					throw new OnBaseAPIException(e);
					
			} catch (IOException e) {
				throw new OnBaseAPIException(e);
				
			}catch(NullPointerException ex){				
				throw new OnBaseAPIException(ex);
				
			}
			finally{
				if(app != null && app.getIsConnected()){
					if(api.closeConnection( app))
						throw new OnBaseAPIException(Mensajes.ERROR_CONEXION_CERRAR+ Calendar.getInstance().getTime());
				}
			}			
		return listaDocumentos;
	}
	
	/**
	 * Retorna un documento por id.
	 * @param idDoc: id del documento a buscar.
	 * @return retorna un objeto de tipo com.bgeneral.interfaces.beans.Document
	 * @throws OnBaseAPIException 	
	 *  
	 */
	public com.bgeneral.interfaces.beans.Document getDocumentById(long idDoc) 
			throws OnBaseAPIException {
		
		APIConnection api = new APIConnection();
		Application app= null;
		com.bgeneral.interfaces.beans.Imaging img = new com.bgeneral.interfaces.beans.Imaging();
		com.bgeneral.interfaces.beans.PageData page = new com.bgeneral.interfaces.beans.PageData();
		com.bgeneral.interfaces.beans.Document documento = new com.bgeneral.interfaces.beans.Document();
		com.bgeneral.interfaces.beans.Rendition ren = null;		
		PageData imagen = null;
			try{
			
				//verificamos si los parametros de la conexi�n existen.
				if(this.conn!= null){
					
					//realizamos la conexi�n.
					 app = api.openConnection(conn);
						
						//verificamos si esta hay conexi�n.
						if(app.getIsConnected()){
						
							Core core = app.getCore();
																				
							Document doc = core.GetDocumentByID(idDoc);
							
							documento.setId(doc.getID());
							documento.setName(doc.getName());	
							documento.setLatestAllowedRevisionID(doc.getLatestAllowedRevisionID());																										
							
							System.out.println("keywordRecords size: "+doc.getKeywordRecords().size());
							
							for(KeywordRecord kr : doc.getKeywordRecords()){									
								System.out.println(kr.getKeywordRecordType().getID()+ " : "+ kr.getKeywordRecordType().getName());
							}
							
							ren = this.mappingRendition(doc.getDefaultRenditionOfLatestRevision());
							
							imagen = core.getRetrieval().getImage().GetDocument(doc.getDefaultRenditionOfLatestRevision());
							
																				
							//Agregando info de la imagen al obj que se regresa.
							
							//Verificamos si viene informaci�n de la imagen.
							if(imagen != null){
								page.setCheque(imagen.getStream());
								page.setExtension(imagen .getExtension());
								img.setPageData(page);
								documento.setImaging(img);
							}
							
//							System.out.println("id: "+ doc.getID()+ " name: "+ doc.getName()+ 
//									"tipo de extension del archivo: "+imagen.getExtension()+ " input Stream : "+ imagen.getStream().toString());
							documento.setRendition(ren);													
							
						}else{
							
							throw new OnBaseAPIException(Mensajes.ERROR_CONEXION);
							
						}
				}else{
					throw new OnBaseAPIException(Mensajes.ERROR_PARAMETROS_CONEXION);
					
				}	//termina condicion que verifica si los parametros de conexi�n existen.
			
	
			}catch(UnityAPIException ex){			
				throw new OnBaseAPIException(ex);
				
			} 
//			catch (IOException e) {
//				throw new OnBaseAPIException(e);
//				
//			}
			catch (InstantiationException e) {				
				throw new OnBaseAPIException(e);
				
			} catch (IllegalAccessException e) {			
					throw new OnBaseAPIException(e);
					
			}catch(NullPointerException ex){				
				throw new OnBaseAPIException(ex);
				
			}
			finally{
				if(app != null && app.getIsConnected()){
					if(api.closeConnection( app))
						throw new OnBaseAPIException(Mensajes.ERROR_CONEXION_CERRAR+ Calendar.getInstance().getTime());									
						
				}
			}					
	
		return documento;
	}
	
	
	/**
	 * metodo que regresa una lista de documentos basados en un rango de fechas
	 * @param fechaInicio: fecha de inicio de la b�squeda.
	 * @param fechaFinal: fecha final de la b�squeda.
	 * @param tipoDocumentoBandera: Variable que nos indica el tipo de imagen  a devolver T = Text, P = PDF, I = Imagen y es la que se busca por defecto.
	 * @param maxDocs: n�mero maximo de registros a buscar.
	 * @return	  retorna una lista de tipo com.bgeneral.interfaces.beans.Document
	 * @throws OnBaseAPIException
	 */
						
	public List<com.bgeneral.interfaces.beans.Document> findDocumentsDateRange(Date fechaInicio, Date fechaFinal,String tipoDocumentoBandera, long maxDocs)
			throws OnBaseAPIException{
		
		APIConnection api = new APIConnection();
		Application app= null;
		List<com.bgeneral.interfaces.beans.Document> listaDocumentos = new ArrayList<>();		
		
		try{
			//verificamos si los parametros de la conexi�n existen.
			if(this.conn!= null){
				
				//realizamos la conexi�n.
				 app = api.openConnection(conn);
					
					//verificamos si esta hay conexi�n.
					if(app.getIsConnected()){						
					
						Core core = app.getCore();
						
						//Creamos el query.
						DocumentQuery query = core.CreateDocumentQuery();				
						query.AddDateRange(fechaInicio, fechaFinal);
						
						//Ejecutamos.
						DocumentList docs = query.Execute(maxDocs);		

						listaDocumentos = mappingDocument(docs, core, tipoDocumentoBandera);
						
					}else{
						
						throw new OnBaseAPIException(Mensajes.ERROR_CONEXION);
						
					}
			}else{
				throw new OnBaseAPIException(Mensajes.ERROR_PARAMETROS_CONEXION);
				
			}	//termina condicion que verifica si los parametros de conexi�n existen.
			
			

		}catch(UnityAPIException ex){			
			throw new OnBaseAPIException(ex);
			
		} catch (InstantiationException e) {			
			throw new OnBaseAPIException(e);
			
		} catch (IllegalAccessException e) {			
				throw new OnBaseAPIException(e);
				
		} catch (IOException e) {
			throw new OnBaseAPIException(e);
			
		}catch(NullPointerException ex){				
			throw new OnBaseAPIException(ex);
			
		}
		finally{
			if(app != null && app.getIsConnected()){				
				if(api.closeConnection( app))
					throw new OnBaseAPIException(Mensajes.ERROR_CONEXION_CERRAR+ Calendar.getInstance().getTime());
			}
		}
		return listaDocumentos;
	}
	
	
	/**
	 * Busca documentos por rango de fecha y los filtra por el id o nombre del tipo de documento.
	 * @param fechaInicio: fecha que marca el inicio de la b�squeda.
	 * @param fechaFinal: fecha que marca el final de la b�squeda.
	 * @param maxDocs: n�mero maximo de registros a buscar.
	 * @param valorDocumentType: nombre del tipo de documento que vamos a buscar.
	 * @param idDocumentType: id del tipo de documento que vamos a buscar.
	 * @param tipoDocumentoBandera: Variable que nos indica el tipo de imagen  a devolver T = Text, P = PDF, I = Imagen y es la que se busca por defecto.
	 * @return regresa una lista de tipo List<com.bgeneral.interfaces.beans.Document>
	 * @throws OnBaseAPIException
	 */
						
	public List<com.bgeneral.interfaces.beans.Document> findDocumentsByDateRangeAndDocumentType(Date fechaInicio, 
			Date fechaFinal, long maxDocs, String valorDocumentType, long idDocumentType, String tipoDocumentoBandera)
			throws OnBaseAPIException{
		
		APIConnection api = new APIConnection();
		Application app= null;
		List<com.bgeneral.interfaces.beans.Document> listaDocumentos = new ArrayList<>();
		com.bgeneral.interfaces.beans.Document documento = new com.bgeneral.interfaces.beans.Document();
		DocumentTypeList documentTypeList=null;
		DocumentType documentType=null;
		
		try{
			//verificamos si los parametros de la conexi�n existen.
			if(this.conn!= null){
				
				//realizamos la conexi�n.
				 app = api.openConnection(conn);
					
					//verificamos si esta hay conexi�n.
					if(app.getIsConnected()){						
						
						Core core = app.getCore();
											
						
						//Buscamos la lista de los tipos de documentos que existen.
						documentTypeList = core.getDocumentTypes();
						
						/*Esta condici�n nos permite hacer la diferencia en si buscamos el tipo de documento por el id
						 * o si lo buscamos por el nombre o descripci�n.
						 * */
						
						if(idDocumentType >0){						
							documentType = documentTypeList.Find(idDocumentType);
						}else{
							if(valorDocumentType == null || "".equals(valorDocumentType)){
								throw new OnBaseAPIException(Mensajes.ERROR_MSJ_findDocumentsByDateRangeAndDocumentType);
								
							}						
							documentType = documentTypeList.Find(valorDocumentType);
						}
						
						
						//Creamos query.
						DocumentQuery query = core.CreateDocumentQuery();					
						query.AddDateRange(fechaInicio, fechaFinal);
						query.AddDocumentType(documentType);
						
						//Ejecutamos.
						DocumentList docs = query.Execute(maxDocs);	
						
						listaDocumentos = mappingDocument(docs, core,tipoDocumentoBandera);
						
//						for(Document doc : docs){			
//							documento = new com.bgeneral.interfaces.beans.Document();
//							
//							documento.setId(doc.getID());
//							documento.setName(doc.getName());
//							
//							listaDocumentos.add(documento);
//						}
					}else{
						
						throw new OnBaseAPIException(Mensajes.ERROR_CONEXION);
						
					}
			}else{
				throw new OnBaseAPIException(Mensajes.ERROR_PARAMETROS_CONEXION);
				
			}	//termina condicion que verifica si los parametros de conexi�n existen.
			
			
		}catch(UnityAPIException ex){			
			throw new OnBaseAPIException(ex);
			
		} catch (InstantiationException e) {			
			throw new OnBaseAPIException(e);
			
		} catch (IllegalAccessException e) {			
				throw new OnBaseAPIException(e);
				
		} catch (IOException e) {		
			throw new OnBaseAPIException(e);
			
		}catch(NullPointerException ex){				
			throw new OnBaseAPIException(ex);
			
		}
		finally{
			if(app != null && app.getIsConnected()){
				if(api.closeConnection( app))
					throw new OnBaseAPIException(Mensajes.ERROR_CONEXION_CERRAR+ Calendar.getInstance().getTime());
			}
		}
	
		return listaDocumentos;

	}
	
	/**
	 * busca por rango de fechas y n�mero de cuenta.
	 * @param fechaInicio: fecha que da inicio al rango de b�squeda.
	 * @param fechaFinal: fecha que marca el final del rango de b�squed.
	 * @param maxDocs: n�mero maximo de resultados a buscar.
	 * @param cuenta: n�mero de cuenta por el cual vamos a filtrar los resultados.
	 * @return retorna una lista de tipo com.bgeneral.interfaces.beans.Document
	 * @throws OnBaseAPIException
	 */	
						
	public List<com.bgeneral.interfaces.beans.Document> findDocumentsByDateRangeAndAccount(Date fechaInicio, Date fechaFinal, long maxDocs, String cuenta)
			throws OnBaseAPIException{
		// 0301010672188
		APIConnection api = new APIConnection();
		Application app= null;
		com.bgeneral.interfaces.beans.Imaging img = new com.bgeneral.interfaces.beans.Imaging();
		com.bgeneral.interfaces.beans.PageData page = new com.bgeneral.interfaces.beans.PageData();
		List<com.bgeneral.interfaces.beans.Document> listaDocumentos = new ArrayList<>();
		com.bgeneral.interfaces.beans.Document documento = new com.bgeneral.interfaces.beans.Document();
		com.bgeneral.interfaces.beans.Rendition ren = null;
		PageData imagen= null;
		try{
			//verificamos si los parametros de la conexi�n existen.
			if(this.conn!= null){
				
				//realizamos la conexi�n.
				 app = api.openConnection(conn);
					
					//verificamos si esta hay conexi�n.
					if(app.getIsConnected()){						
					
						Core core = app.getCore();
						
						//Creamos el query.
						DocumentQuery query = core.CreateDocumentQuery();					
						query.AddDateRange(fechaInicio, fechaFinal);
						
						//Ejecutamos.
						DocumentList docs = query.Execute(maxDocs);
							
					
						for(Document doc : docs){
						
							if(doc.getName().contains(cuenta)){
								documento = new com.bgeneral.interfaces.beans.Document();
								
								documento.setId(doc.getID());
								documento.setName(doc.getName());
								documento.setCuentaAbuscar(cuenta);
								
															
								ren = this.mappingRendition(doc.getDefaultRenditionOfLatestRevision());
																																			
								imagen = core.getRetrieval().getImage().GetDocument(doc.getDefaultRenditionOfLatestRevision());
								
								//Agregando info de la imagen al obj que se regresa.
								
								//Verificamos si viene informaci�n de la imagen.
								if(imagen != null){
									page.setCheque(imagen.getStream());
									page.setExtension(imagen .getExtension());
									img.setPageData(page);
									documento.setImaging(img);
								}
								
								documento.setRendition(ren);		;	
								
								listaDocumentos.add(documento);
	
								
							}
						
						}

					}else{
						
						throw new OnBaseAPIException(Mensajes.ERROR_CONEXION);
						
					}
			}else{
				throw new OnBaseAPIException(Mensajes.ERROR_PARAMETROS_CONEXION);
				
			}	//termina condicion que verifica si los parametros de conexi�n existen.
			
			
		}catch(UnityAPIException ex){			
			throw new OnBaseAPIException(ex);
			
		} catch (InstantiationException e) {			
			throw new OnBaseAPIException(e);
			
		} catch (IllegalAccessException e) {			
				throw new OnBaseAPIException(e);
				
		}catch(NullPointerException ex){				
			throw new OnBaseAPIException(ex);
			
		}
		finally{
			if(app != null && app.getIsConnected()){
				if(api.closeConnection( app))
					throw new OnBaseAPIException(Mensajes.ERROR_CONEXION_CERRAR+ Calendar.getInstance().getTime());
			}
		}
		
		return listaDocumentos;

	}

	/**
	 * M�todo el cual busca documentos por una palabra clave.
	 * @param palabraClave: cadena alfanumerica por el cual vamos a realizar la b�squeda.
	 * @param tipoDocumentoBandera: Variable que nos indica el tipo de imagen  a devolver T = Text, P = PDF, I = Imagen y es la que se busca por defecto.
	 * @param maxDocs: n�mero m�ximo de documentos a regresar.
	 * @return retorna una lista de tipo List<com.bgeneral.interfaces.beans.Document>
	 * @throws OnBaseAPIException
	 */
	public List<com.bgeneral.interfaces.beans.Document> findDocumentByKeyword( String palabraClave, String tipoDocumentoBandera, long maxDocs)
			throws OnBaseAPIException{
			
		DocumentList docs = null;
		APIConnection api = new APIConnection();
		Application app= null;
		List<com.bgeneral.interfaces.beans.Document> listaDocumentos = new ArrayList<>();
		com.bgeneral.interfaces.beans.Document documento = new com.bgeneral.interfaces.beans.Document();
		
		try{
			//verificamos si los parametros de la conexi�n existen.
			if(this.conn!= null){
				
				//realizamos la conexi�n.
				 app = api.openConnection(conn);
					
					//verificamos si esta hay conexi�n.
					if(app.getIsConnected()){						
						
						Core core = app.getCore();
						
						//obteniendo las propiedades de la palabra clave.
						KeywordTypeList keywordList = core.getKeywordTypes();	//buscamos todas las palabras claves.
						
						KeywordType keywordType = keywordList.Find(palabraClave);	//filtramos por la palabra clave.
						
						
						
						//verifica s� recupero las propiedades de la palabra clave a buscar.
						if(keywordType!= null){
						
							//Creaci�n del query.
							DocumentQuery query = core.CreateDocumentQuery();						
							
							
							//verificamos si tipo de dato que es(Numerico o alfanumerico)
							if( keywordType.getDataType().AlphaNumeric.name().equals(keywordType.getDataType().name())){				
								query.AddKeyword(keywordType.getName(), ""+keywordType.getID());
							}else{							
								query.AddKeyword(keywordType.getName(), keywordType.getID());			
							}					
							
							//Ejecuci�n del query.
							docs = query.Execute(maxDocs);			
							
							//Recorremos.
							listaDocumentos = mappingDocument(docs, core, tipoDocumentoBandera);
							
						}	//cierra condificion que valida el keywordType.
					}else{
						
						throw new OnBaseAPIException(Mensajes.ERROR_CONEXION);
						
					}
			}else{
				throw new OnBaseAPIException(Mensajes.ERROR_PARAMETROS_CONEXION);
				
			}	//termina condicion que verifica si los parametros de conexi�n existen.
			
		
		}catch(UnityAPIException ex){			
			throw new OnBaseAPIException(ex);
			
		} catch (InstantiationException e) {			
			throw new OnBaseAPIException(e);
			
		} catch (IllegalAccessException e) {			
				throw new OnBaseAPIException(e);
				
		} catch (IOException e) {
			throw new OnBaseAPIException(e);
			
		}catch(NullPointerException ex){				
			throw new OnBaseAPIException(ex);
			
		}
		finally{
			if(app != null && app.getIsConnected()){
				if(api.closeConnection( app))
					throw new OnBaseAPIException(Mensajes.ERROR_CONEXION_CERRAR+ Calendar.getInstance().getTime());
			}
		}
		
		return listaDocumentos;		

	}
	
	
	/**
	 * metodo que busca por un rango de fecha, y una palabra clave una lista de documentos.
	 * @param fechaInicio: fecha que inicia el rango de la b�squeda.
	 * @param fechaFinal: fecha que finaliza el rango de la b�squeda.
	 * @param palabraClave: palabra por la cual vamos a realizar la b�squeda.
	 * @param maxDocs: n�mero m�ximo de documentos a regresar.
	 * @param tipoDocumentoBandera: Variable que nos indica el tipo de imagen  a devolver T = Text, P = PDF, I = Imagen y es la que se busca por defecto.
	 * @return	 regresa una lista de tipo com.bgeneral.interfaces.beans.Document
	 * @throws OnBaseAPIException
	 */
	public List<com.bgeneral.interfaces.beans.Document> findDocumentByKeywordAndDateRange(Date fechaInicio, Date fechaFinal, 
			String palabraClave, String tipoDocumentoBandera, long maxDocs)
			throws OnBaseAPIException{
			
		DocumentList docs = null;
		APIConnection api = new APIConnection();
		Application app= null;
		List<com.bgeneral.interfaces.beans.Document> listaDocumentos = new ArrayList<>();
		com.bgeneral.interfaces.beans.Document documento = new com.bgeneral.interfaces.beans.Document();
		
		try{
			//verificamos si los parametros de la conexi�n existen.
			if(this.conn!= null){
				
				//realizamos la conexi�n.
				 app = api.openConnection(conn);
					
					//verificamos si esta hay conexi�n.
					if(app.getIsConnected()){						
						
						Core core = app.getCore();
						
						//obteniendo las propiedades de la palabra clave.
						KeywordTypeList keywordList = core.getKeywordTypes();	//buscamos todas las palabras claves.
						
						KeywordType keywordType = keywordList.Find(palabraClave);	//filtramos por la palabra clave.
						
						//verifica s� recupero las propiedades de la palabra clave a buscar.
						if(keywordType!= null){
						
							//Creamos el query.
							DocumentQuery query = core.CreateDocumentQuery();						
							query.AddDateRange(fechaInicio, fechaFinal);
//							query.AddDisplayColumn(keywordType);
							
//							//verificamos si tipo de dato que es(Numerico o alfanumerico)
							if( keywordType.getDataType().AlphaNumeric.name().equals(keywordType.getDataType().name())){				
								query.AddKeyword(keywordType.getName(), ""+keywordType.getID());
							}else{							
								query.AddKeyword(keywordType.getName(), keywordType.getID());
								
							}
							
							//Ejecutamos.
							docs = query.Execute(maxDocs);
							
							listaDocumentos = mappingDocument(docs, core, tipoDocumentoBandera);
							
						}	//cierra condifici�n que verifica el keywordType.
					}else{
						
						throw new OnBaseAPIException(Mensajes.ERROR_CONEXION);
						
					}
			}else{
				throw new OnBaseAPIException(Mensajes.ERROR_PARAMETROS_CONEXION);
				
			}	//termina condicion que verifica si los parametros de conexi�n existen.
			
		
		}catch(UnityAPIException ex){			
			throw new OnBaseAPIException(ex);
			
		} catch (InstantiationException e) {			
			throw new OnBaseAPIException(e);
			
		} catch (IllegalAccessException e) {			
				throw new OnBaseAPIException(e);
				
		} catch (IOException e) {
			throw new OnBaseAPIException(e);
			
		}catch(NullPointerException ex){				
			throw new OnBaseAPIException(ex);
			
		}
		finally{
			if(app != null && app.getIsConnected()){
				if(api.closeConnection( app))
					throw new OnBaseAPIException(Mensajes.ERROR_CONEXION_CERRAR+ Calendar.getInstance().getTime());
			}
		}
		
		return listaDocumentos;		

	}
	
	
	/**
	 * M�todo que busca lista de documentos basados en una serie de par�metros.
	 * @param fechaInicio: fecha que indica en rango de inicio de la b�squeda. Opcional
	 * @param fechaFinal: fecha que indica la culminaci�n del rango de la b�squeda. Opcional
	 * @param palabraClave: keyword por el cual vamos a filtrar. Opcional
	 * @param maxDocs: n�mero maximo de documentos a regresar.
	 * @param idDocumentType: id del tipo de documento por el cual deseamos realizar la b�squeda. Opcional
	 * @param idTypeGroup: id del grupo de tipo de documento por el cual deseamos realizar la b�squeda. Opcional.
	 * @param cuenta: n�mero de cuenta por al cual filtraremos los resultados. Opcional.
	 * @param tipoDocumentoBandera: Variable que nos indica el tipo de imagen  a devolver T = Text, P = PDF, I = Imagen y es la que se busca por defecto.
	 * @return: retorna una lista de documentos de tipo com.bgeneral.interfaces.beans.Document.
	 * @throws OnBaseAPIException
	 */
	public List<com.bgeneral.interfaces.beans.Document> getDocumentList(Date fechaInicio, Date fechaFinal, String palabraClave, long maxDocs,
			long idDocumentType, long idTypeGroup, String cuenta, String tipoDocumentoBandera)
			throws OnBaseAPIException{
					
		
		DocumentList docs = null;
		APIConnection api = new APIConnection();
		Application app= null;
		List<com.bgeneral.interfaces.beans.Document> listaDocumentos = new ArrayList<>();
		com.bgeneral.interfaces.beans.Document documento = new com.bgeneral.interfaces.beans.Document();
		com.bgeneral.interfaces.beans.Imaging img = new com.bgeneral.interfaces.beans.Imaging();
		com.bgeneral.interfaces.beans.PageData page = new com.bgeneral.interfaces.beans.PageData();
		List<com.bgeneral.interfaces.beans.Document> listaDocumento = new ArrayList<>();
	
		com.bgeneral.interfaces.beans.Rendition ren = null;		
		PageData imagen = null;				
		DocumentTypeList documentTypeList = null;
		DocumentType documentType=null;
		DocumentTypeGroupList documentTypeGroupList = null;
		DocumentTypeGroup documentTypeGroup = null;
		try{
			//verificamos si los parametros de la conexi�n existen.
			if(this.conn!= null){
				
				//realizamos la conexi�n.
				 app = api.openConnection(conn);
					
					//verificamos si esta hay conexi�n.
					if(app.getIsConnected()){																				
						
						Core core = app.getCore();
						
						//Creamos el query.
						DocumentQuery query = core.CreateDocumentQuery();
						
						
						//Buscamos la informaci�n para el documentType.
						if(idDocumentType >0){
							documentTypeList = core.getDocumentTypes();	//buscamos todos los tipos de documentos.
							
							documentType = documentTypeList.Find(idDocumentType);	//filtramos por el id.
							
							query.AddDocumentType(documentType);
						}
						
						
						
						//Buscamos la informaci�n para el documentTypeGroup.
						if(idTypeGroup >0){
							documentTypeGroupList = core.getDocumentTypeGroups();	//buscamos todos los grupos de tipos de documentos.
							
							documentTypeGroup = documentTypeGroupList.Find(idTypeGroup);	//filtramos por el id.
							query.AddDocumentTypeGroup(documentTypeGroup);
							
						}
						
						//Agregamos el rango de fechas.
						if(fechaInicio !=null && fechaFinal != null)
							query.AddDateRange(fechaInicio, fechaFinal);
						
						//obteniendo las propiedades de la palabra clave.					
						
						KeywordTypeList keywordList = core.getKeywordTypes();	//buscamos todas las palabras claves.
						
						KeywordType keywordType = keywordList.Find(palabraClave);	//filtramos por la palabra clave.
						
						//verifica s� recupero las propiedades de la palabra clave a buscar.
						if(keywordType!= null){												
							
							//verificamos si tipo de dato que es(Numerico o alfanumerico)
							if( keywordType.getDataType().AlphaNumeric.name().equals(keywordType.getDataType().name())){				
								query.AddKeyword(keywordType.getName(), ""+keywordType.getID());
							}else{							
								query.AddKeyword(keywordType.getName(), keywordType.getID());
								
							}
							
																			
						}
						
						//Ejecutamos.
						docs = query.Execute(maxDocs);
						
						
						for(Document doc : docs){
							
						
							if(cuenta !=null){
								if(doc.getName().contains(cuenta)){
									documento = new com.bgeneral.interfaces.beans.Document();
									
									documento.setId(doc.getID());
									documento.setName(doc.getName());
									documento.setLatestAllowedRevisionID(doc.getLatestAllowedRevisionID());
									
									ren = this.mappingRendition(doc.getDefaultRenditionOfLatestRevision());
									
								
									//Si el documento lo quieres extraer por texto. Reportes = textos
									 if("T".equals(tipoDocumentoBandera.toUpperCase())){
										imagen = core.getRetrieval().getText().GetDocument(doc.getDefaultRenditionOfLatestRevision());
										
									}else if("P".equals(tipoDocumentoBandera.toUpperCase())){	//Si lo quieres extraer en PDF.
										imagen = core.getRetrieval().getPDF().GetDocument(doc.getDefaultRenditionOfLatestRevision());
										
									}else{	// Por defecto Saca la imagen.
										imagen = core.getRetrieval().getImage().GetDocument(doc.getDefaultRenditionOfLatestRevision());
									}
																		
									
									//Agregando info de la imagen al obj que se regresa.
									
									//Verificamos si viene informaci�n de la imagen.
									if(imagen != null){
										page = new com.bgeneral.interfaces.beans.PageData();
										img = new com.bgeneral.interfaces.beans.Imaging();
										
										page.setCheque(imagen.getStream());
										page.setExtension(imagen .getExtension());
										img.setPageData(page);
										documento.setImaging(img);
									}
									documento.setRendition(ren);			
																		
									listaDocumento.add(documento);
								}		//cierra instruccion que verifica la cuenta.
								
							}else{
								documento = new com.bgeneral.interfaces.beans.Document();
								
								documento.setId(doc.getID());
								documento.setName(doc.getName());
								documento.setLatestAllowedRevisionID(doc.getLatestAllowedRevisionID());
								
								ren = this.mappingRendition(doc.getDefaultRenditionOfLatestRevision());
								
							
								//Si el documento lo quieres extraer por texto. Reportes = textos
								 if("T".equals(tipoDocumentoBandera.toUpperCase())){
									imagen = core.getRetrieval().getText().GetDocument(doc.getDefaultRenditionOfLatestRevision());
									
								}else if("P".equals(tipoDocumentoBandera.toUpperCase())){	//Si lo quieres extraer en PDF.
									imagen = core.getRetrieval().getPDF().GetDocument(doc.getDefaultRenditionOfLatestRevision());
									
								}else{	// Por defecto Saca la imagen.
									imagen = core.getRetrieval().getImage().GetDocument(doc.getDefaultRenditionOfLatestRevision());
								}
																	
								
								//Agregando info de la imagen al obj que se regresa.
								
								//Verificamos si viene informaci�n de la imagen.
								if(imagen != null){
									page = new com.bgeneral.interfaces.beans.PageData();
									img = new com.bgeneral.interfaces.beans.Imaging();
									
									page.setCheque(imagen.getStream());
									page.setExtension(imagen .getExtension());
									img.setPageData(page);
									documento.setImaging(img);
								}
								documento.setRendition(ren);			
																	
								listaDocumento.add(documento);
							}
							
							
						
							
						}	//cierra condifici�n que verifica el keywordType.
					
						
					}else{
						
						throw new OnBaseAPIException(Mensajes.ERROR_CONEXION);
						
					}
			}else{
				throw new OnBaseAPIException(Mensajes.ERROR_PARAMETROS_CONEXION);
				
			}	//termina condicion que verifica si los parametros de conexi�n existen.
			
		
		}catch(UnityAPIException ex){			
			throw new OnBaseAPIException(ex);
			
		} catch (InstantiationException e) {			
			throw new OnBaseAPIException(e);
			
		} catch (IllegalAccessException e) {			
				throw new OnBaseAPIException(e);
				
		}
//		catch (IOException e) {
//			throw new OnBaseAPIException(e);
//			
//		}
		catch(NullPointerException ex){				
			throw new OnBaseAPIException(ex);
			
		}
		finally{
			if(app != null && app.getIsConnected()){
				if(api.closeConnection( app))
					throw new OnBaseAPIException(Mensajes.ERROR_CONEXION_CERRAR+ Calendar.getInstance().getTime());
			}
		}
		
		return listaDocumentos;		

	}
	
	
	/**
	 * M�todo que devuelve una lista de documentos basados en una serie de par�metros.
	 * @param fechaInicio: fecha que marca el inicio del rango de b�squeda. Opcional
	 * @param fechaFinal:  fecha que marca el final del rango de b�squeda. Opcional
	 * @param palabraClave: palabra por la cual vamos a buscar.Opcional
	 * @param maxDocs: n�mero m�ximo de registros que queremos devolver.
	 * @param idDocumentType: id del tipo de documento que deseamos usar para la b�squeda. Opcional
	 * @param idTypeGroup: id del grupo de tipo de documeno que deseamos usar para la buscar. Opcional
	 * @param cuenta:  n�mero de cuenta por el cual vamos a filtrar el resultado. Opcional
	 * @param rangoInicio: par�metro que nos marca el inicio del n�mero de paginas de un documento que deseamos devolver.Opcional.
	 * @param rangoFinal: par�metro que nos marca el final del n�mero de p�ginas de un documento que deseamos devolver. Opcional.
	 * @return retorna una lista de documentos de tipo com.bgeneral.interfaces.beans.Document
	 * @throws OnBaseAPIException
	 */
	public List<com.bgeneral.interfaces.beans.Document> getDocumentList(Date fechaInicio, Date fechaFinal, String palabraClave, long maxDocs,
			long idDocumentType, long idTypeGroup, String cuenta, long rangoInicio, long rangoFinal)
			throws OnBaseAPIException{
			
		
		
		DocumentList docs = null;
		APIConnection api = new APIConnection();
		Application app= null;
		List<com.bgeneral.interfaces.beans.Document> listaDocumentos = new ArrayList<>();
		com.bgeneral.interfaces.beans.Document documento = new com.bgeneral.interfaces.beans.Document();
		com.bgeneral.interfaces.beans.Imaging img = new com.bgeneral.interfaces.beans.Imaging();
		com.bgeneral.interfaces.beans.PageData page = new com.bgeneral.interfaces.beans.PageData();
		List<com.bgeneral.interfaces.beans.Document> listaDocumento = new ArrayList<>();
	
		com.bgeneral.interfaces.beans.Rendition ren = null;		
		PageData imagen = null;				
		DocumentTypeList documentTypeList = null;
		DocumentType documentType=null;
		DocumentTypeGroupList documentTypeGroupList = null;
		DocumentTypeGroup documentTypeGroup = null;
		PageRangeSet pageRange = null;
		PageDataList pageDataList = null;
		try{
			//verificamos si los parametros de la conexi�n existen.
			if(this.conn!= null){
				
				//realizamos la conexi�n.
				 app = api.openConnection(conn);
					
					//verificamos si esta hay conexi�n.
					if(app.getIsConnected()){																				
						
						Core core = app.getCore();
						
						//Creamos el query.
						DocumentQuery query = core.CreateDocumentQuery();	

						//Buscamos la informaci�n para el documentType.
						if(idDocumentType >0){
						
							documentTypeList = core.getDocumentTypes();	//buscamos todos los tipos de documentos.
							
							documentType = documentTypeList.Find(idDocumentType);	//filtramos por el id.
							
							query.AddDocumentType(documentType);
						}
						
						//Buscamos la informaci�n para el documentTypeGroup.
						if(idTypeGroup >0){

							documentTypeGroupList = core.getDocumentTypeGroups();	//buscamos todos los grupos de tipos de documentos.
							
							documentTypeGroup = documentTypeGroupList.Find(idTypeGroup);	//filtramos por el id.
							
							query.AddDocumentTypeGroup(documentTypeGroup);
						}
						
						
						if(fechaInicio !=null && fechaFinal != null)
							query.AddDateRange(fechaInicio, fechaFinal);
						
						
						
						//obteniendo las propiedades de la palabra clave.						
						KeywordTypeList keywordList = core.getKeywordTypes();	//buscamos todas las palabras claves.
						
						if(palabraClave!= null){
							KeywordType keywordType = keywordList.Find(palabraClave);	//filtramos por la palabra clave.																			
						
							//verifica s� recupero las propiedades de la palabra clave a buscar.
							if(keywordType!= null){													
								
	//							//verificamos si tipo de dato que es(Numerico o alfanumerico)
								if( keywordType.getDataType().AlphaNumeric.name().equals(keywordType.getDataType().name())){				
									query.AddKeyword(keywordType.getName(), ""+keywordType.getID());
									
								}else{							
									query.AddKeyword(keywordType.getName(), keywordType.getID());
									
								}
	//											
								
							}	//cierra condifici�n que verifica el keywordType.
						}
						
						//Ejecutamos.
						docs = query.Execute(maxDocs);
						
						for(Document doc : docs){
							
							documento = new com.bgeneral.interfaces.beans.Document();
							
//						Filtramos por el n�mero de cuenta.
							if(cuenta !=null){
								
							
								if(doc.getName().contains(cuenta)){														
									documento.setId(doc.getID());
									documento.setName(doc.getName());
									documento.setLatestAllowedRevisionID(doc.getLatestAllowedRevisionID());															
									
									ren = this.mappingRendition(doc.getDefaultRenditionOfLatestRevision());
												
								
										
										//verificamos si los rango de paginas son mayores o iguales a cero.
										if(rangoInicio>=0 && rangoFinal >=0){
											
											pageRange = core.getRetrieval().getImage().CreatePageRangeSet();
											
											pageRange.AddRange(rangoInicio, rangoFinal);
											
											pageDataList = core.getRetrieval().getImage().
													GetPages(doc.getDefaultRenditionOfLatestRevision(), pageRange);
																					
											
											//Recorremos la lista de las imagenes que se encontraron en el rango.
											for(PageData p : pageDataList){
												page = new com.bgeneral.interfaces.beans.PageData();
												page.setCheque(p.getStream());
												page.setExtension(p.getExtension());
												
												img = new com.bgeneral.interfaces.beans.Imaging();
												img.setPageData(page);
												documento.setImaging(img);										 
											}
										}else{
											imagen = core.getRetrieval().getImage().GetDocument(doc.getDefaultRenditionOfLatestRevision());																											
											
											//Verificamos si viene informaci�n de la imagen.
											if(imagen != null){
												page = new com.bgeneral.interfaces.beans.PageData();
												img = new com.bgeneral.interfaces.beans.Imaging();
												
												page.setCheque(imagen.getStream());
												page.setExtension(imagen .getExtension());
												img.setPageData(page);
												documento.setImaging(img);
											}
												
										}
										
															
								
							}
						}else{
							documento.setId(doc.getID());
							documento.setName(doc.getName());
							documento.setLatestAllowedRevisionID(doc.getLatestAllowedRevisionID());															
							
							ren = this.mappingRendition(doc.getDefaultRenditionOfLatestRevision());
										
						
							//verificamos si los rango de paginas son mayores o iguales a cero.
							if(rangoInicio>=0 && rangoFinal >=0){
								
								pageRange = core.getRetrieval().getImage().CreatePageRangeSet();
								
								pageRange.AddRange(rangoInicio, rangoFinal);
								
								pageDataList = core.getRetrieval().getImage().
										GetPages(doc.getDefaultRenditionOfLatestRevision(), pageRange);
																		
								
								//Recorremos la lista de las imagenes que se encontraron en el rango.
								for(PageData p : pageDataList){
									page = new com.bgeneral.interfaces.beans.PageData();
									page.setCheque(p.getStream());
									page.setExtension(p.getExtension());
									
									img = new com.bgeneral.interfaces.beans.Imaging();
									img.setPageData(page);
									documento.setImaging(img);										 
								}
							}else{
								imagen = core.getRetrieval().getImage().GetDocument(doc.getDefaultRenditionOfLatestRevision());																											
								
								//Verificamos si viene informaci�n de la imagen.
								if(imagen != null){
									page = new com.bgeneral.interfaces.beans.PageData();
									img = new com.bgeneral.interfaces.beans.Imaging();
									
									page.setCheque(imagen.getStream());
									page.setExtension(imagen .getExtension());
									img.setPageData(page);
									documento.setImaging(img);
								}
									
							}

																					
						}
							
							documento.setRendition(ren);			
							
							listaDocumento.add(documento);
							
						}	//cierra el for que recorre los documentos.
					}else{
						
						throw new OnBaseAPIException(Mensajes.ERROR_CONEXION);
						
					}
			}else{
				throw new OnBaseAPIException(Mensajes.ERROR_PARAMETROS_CONEXION);
				
			}	//termina condicion que verifica si los parametros de conexi�n existen.
			
		
		}catch(UnityAPIException ex){			
			throw new OnBaseAPIException(ex);
			
		} catch (InstantiationException e) {			
			throw new OnBaseAPIException(e);
			
		} catch (IllegalAccessException e) {			
				throw new OnBaseAPIException(e);
				
		}
//		catch (IOException e) {
//			throw new OnBaseAPIException(e);
//			
//		}
		catch(NullPointerException ex){				
			throw new OnBaseAPIException(ex);
			
		}
		finally{
			if(app != null && app.getIsConnected()){
				if(api.closeConnection( app))
					throw new OnBaseAPIException(Mensajes.ERROR_CONEXION_CERRAR+ Calendar.getInstance().getTime());
			}
		}
		
		return listaDocumentos;		

	}
	
	
	/**
	 * 
	 * @param palabrasClaves: mapa de las palabras claves a buscar.
	 * @param maxDocs: n�mero m�ximo de registros a buscar.
	 * @param idDocumentType id del tipo de documento por el cual vamos a realizar la b�squeda. Opcional.
	 * @param idTypeGroup: id del grupo de tipo de documento por el cual vamos a realizar la b�squeda. Opcional.
	 * @param tipoDocumentoBandera
	 * @return
	 * @throws OnBaseAPIException
	 */
	public List<com.bgeneral.interfaces.beans.Document> getDocumentList( Map<String, Object> palabrasClaves, long maxDocs,
			long idDocumentType, long idTypeGroup, String tipoDocumentoBandera)
			throws OnBaseAPIException{
			
		
		
		DocumentList docs = null;
		APIConnection api = new APIConnection();
		Application app= null;
		List<com.bgeneral.interfaces.beans.Document> listaDocumentos = new ArrayList<>();
		com.bgeneral.interfaces.beans.Document documento = new com.bgeneral.interfaces.beans.Document();
		com.bgeneral.interfaces.beans.Imaging img = new com.bgeneral.interfaces.beans.Imaging();
		com.bgeneral.interfaces.beans.PageData page = new com.bgeneral.interfaces.beans.PageData();
		List<com.bgeneral.interfaces.beans.Document> listaDocumento = new ArrayList<>();
	
		com.bgeneral.interfaces.beans.Rendition ren = null;		
		PageData imagen = null;				
		DocumentTypeList documentTypeList = null;
		DocumentType documentType=null;
		DocumentTypeGroupList documentTypeGroupList = null;
		DocumentTypeGroup documentTypeGroup = null;		
		QueryKeywordRecord queryKeyword= null;
		KeywordType keywordType = null;		
		try{
			//verificamos si los parametros de la conexi�n existen.
			if(this.conn!= null){
				
				//realizamos la conexi�n.
				 app = api.openConnection(conn);
					
					//verificamos si esta hay conexi�n.
					if(app.getIsConnected()){																				
						
						Core core = app.getCore();
						
						//Creamos el query.
						DocumentQuery query = core.CreateDocumentQuery();
						
						
						
						//Buscamos la informaci�n para el documentType.		
						if(idDocumentType > 0){
							documentTypeList = core.getDocumentTypes();	//buscamos todos los tipos de documentos.
							
							documentType = documentTypeList.Find(idDocumentType);	//filtramos por el id.
							
							query.AddDocumentType(documentType);	//agregamos el documentType.
						}
						
						
						
						//Buscamos la informaci�n para el documentTypeGroup.
						if(idTypeGroup > 0){
							documentTypeGroupList = core.getDocumentTypeGroups();	//buscamos todos los grupos de tipos de documentos.
							
							documentTypeGroup = documentTypeGroupList.Find(idTypeGroup);	//filtramos por el id.
							
							query.AddDocumentTypeGroup(documentTypeGroup);	//agregamos al query el documentTypeGroup
						}
						
						
						//Obtenemos todos los keywordRecordTypes que vienen en la conexi�n
						KeywordRecordTypeList recordTypeList = core.getKeywordRecordTypes();
//												
//						//KeywordRecordType : 0 - Standard Keyword 
						KeywordRecordType recordType= recordTypeList.Find(0);
														
						//Creamos el objeto que necesitamos para agregar varios keyword					
						queryKeyword = recordType.CreateQueryKeywordRecord();
						
						//buscamos todas las palabras claves.
						KeywordTypeList keywordList = core.getKeywordTypes();																																																									
										
						//Sacamos las llaves del map que viene en la firma del m�todo
						Set<String>llaves = palabrasClaves.keySet();
						
						//recorremos para obtener las propiedades del kewordType.
						for(String k : llaves){								
								
							keywordType = keywordList.Find(""+palabrasClaves.get(k));
																											
							if(keywordType != null){															
																						
								Keyword key = keywordType.CreateKeyword(""+palabrasClaves.get(k));								
								
								queryKeyword.AddKeyword(key);
														
							}
							
						}//cierra for que recorre las palabras claves.

							if(queryKeyword != null){
								query.AddQueryKeywordRecord(queryKeyword);
								
								
							}
							
							
							//Ejecutamos.
							docs = query.Execute(maxDocs);
							
							//ciclo que recorre los documentos encontrados
							for(Document doc : docs){
															
									documento = new com.bgeneral.interfaces.beans.Document();
																								
									documento.setId(doc.getID());
									documento.setName(doc.getName());
									documento.setLatestAllowedRevisionID(doc.getLatestAllowedRevisionID());															
																	
									
									ren = this.mappingRendition(doc.getDefaultRenditionOfLatestRevision());
																													
										
										//Si el documento lo quieres extraer por texto. Reportes = textos
										 if("T".equals(tipoDocumentoBandera.toUpperCase())){
											imagen = core.getRetrieval().getText().GetDocument(doc.getDefaultRenditionOfLatestRevision());
											
										}else if("P".equals(tipoDocumentoBandera.toUpperCase())){	//Si lo quieres extraer en PDF.
											imagen = core.getRetrieval().getPDF().GetDocument(doc.getDefaultRenditionOfLatestRevision());
											
										}else{	// Por defecto Saca la imagen.
											imagen = core.getRetrieval().getImage().GetDocument(doc.getDefaultRenditionOfLatestRevision());
										}
										
												
																				
										if(imagen != null){
											page = new com.bgeneral.interfaces.beans.PageData();
											img = new com.bgeneral.interfaces.beans.Imaging();
											
											page.setCheque(imagen.getStream());
											page.setExtension(imagen .getExtension());
											img.setPageData(page);
											documento.setImaging(img);
										}																			
											 
//									
									//Agregando info de la imagen al obj que se regresa.
																
									documento.setRendition(ren);			
																		
									listaDocumento.add(documento);
									
								
							}	//cierra for que recorre los documentos encontrados.

				
					}else{
						
						throw new OnBaseAPIException(Mensajes.ERROR_CONEXION);
						
					}
			}else{
				throw new OnBaseAPIException(Mensajes.ERROR_PARAMETROS_CONEXION);
				
			}	//termina condicion que verifica si los parametros de conexi�n existen.
			
		
		}catch(UnityAPIException ex){	
			ex.printStackTrace();
			throw new OnBaseAPIException(ex);
			
		} catch (InstantiationException e) {			
			throw new OnBaseAPIException(e);
			
		} catch (IllegalAccessException e) {			
				throw new OnBaseAPIException(e);
				
		}
//		catch (IOException e) {
//			throw new OnBaseAPIException(e);
//			
//		}
		catch(NullPointerException ex){				
			throw new OnBaseAPIException(ex);
			
		} 
		finally{
			if(app != null && app.getIsConnected()){
				if(api.closeConnection( app))
					throw new OnBaseAPIException(Mensajes.ERROR_CONEXION_CERRAR+ Calendar.getInstance().getTime());
			}
		}
		
		System.out.println("total: "+listaDocumento.size());
		return listaDocumentos;		

	}
	
	
	/**
	 * m�todo que recorre una lista de documentos de tipo Hyland.Unity.DocumentList para mapearlos a un objeto
	 * de tipo com.bgeneral.interfaces.beans.Document propio de este JAR.
	 * @param listDocument: lista de documentos a mapear.
	 * @param core: variable que trae las instancias de la conexi�n.
	 * @param tipoDocumentoBandera: Variable que nos indica el tipo de imagen  a devolver T = Text, P = PDF, I = Imagen y es la que se busca por defecto.
	 * @return retorna una lista de tipo com.bgeneral.interfaces.beans.Document
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 * @throws UnityAPIException
	 * @throws IOException 
	 */
	public List<com.bgeneral.interfaces.beans.Document> mappingDocument(DocumentList listDocument, Core core, String tipoDocumentoBandera)
			throws InstantiationException, IllegalAccessException, UnityAPIException, IOException, NullPointerException {
	
		com.bgeneral.interfaces.beans.Imaging img = new com.bgeneral.interfaces.beans.Imaging();
		com.bgeneral.interfaces.beans.PageData page = new com.bgeneral.interfaces.beans.PageData();
		List<com.bgeneral.interfaces.beans.Document> listaDocumento = new ArrayList<>();
		com.bgeneral.interfaces.beans.Document documento = new com.bgeneral.interfaces.beans.Document();
		com.bgeneral.interfaces.beans.Rendition ren = null;		
		PageData imagen = null;
			
			for(Document doc : listDocument){
				documento = new com.bgeneral.interfaces.beans.Document();
				
				documento.setId(doc.getID());
				documento.setName(doc.getName());
				documento.setLatestAllowedRevisionID(doc.getLatestAllowedRevisionID());
													
				ren = this.mappingRendition(doc.getDefaultRenditionOfLatestRevision());
									
				//Si el documento lo quieres extraer por texto. Reportes = textos
				 if("T".equals(tipoDocumentoBandera.toUpperCase())){
					imagen = core.getRetrieval().getText().GetDocument(doc.getDefaultRenditionOfLatestRevision());
					
				}else if("P".equals(tipoDocumentoBandera.toUpperCase())){	//Si lo quieres extraer en PDF.
					imagen = core.getRetrieval().getPDF().GetDocument(doc.getDefaultRenditionOfLatestRevision());
					
				}else{	// Por defecto Saca la imagen.
					imagen = core.getRetrieval().getImage().GetDocument(doc.getDefaultRenditionOfLatestRevision());
				}
				
				//Agregando info de la imagen al obj que se regresa.
				
				//Verificamos si viene informaci�n de la imagen.
				if(imagen != null){
					page.setCheque(imagen.getStream());
					page.setExtension(imagen .getExtension());
					img.setPageData(page);
					documento.setImaging(img);
				}
				
				documento.setRendition(ren);			
													
				listaDocumento.add(documento);				
				
			}
	

		
		return listaDocumento;
	}		
	

}
