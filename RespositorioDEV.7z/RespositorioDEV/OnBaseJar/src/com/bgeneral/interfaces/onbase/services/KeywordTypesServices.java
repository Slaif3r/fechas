/**
 * 
 */
package com.bgeneral.interfaces.onbase.services;

import java.util.Calendar;

import com.bgeneral.interfaces.beans.Connection;
import com.bgeneral.interfaces.connection.APIConnection;
import com.bgeneral.interfaces.exception.OnBaseAPIException;
import com.bgeneral.interfaces.onbase.utils.Mensajes;

import Hyland.Unity.Application;
import Hyland.Unity.Core;
import Hyland.Unity.Keyword;
import Hyland.Unity.KeywordType;
import Hyland.Unity.KeywordTypeList;
import Hyland.Unity.UnityAPIException;

/**
 * @author jsoto
 *
 */
public class KeywordTypesServices {

	
	Connection conn = new Connection();
	
	KeywordTypeList lista =null;
	
	public KeywordTypesServices(Connection connection){
		
		this.conn = connection;
		
		
	}
	/**
	 * metodo que retorna todas las palabras claves que regresa la conexi�n.
	 * @return
	 * @throws OnBaseAPIException
	 */
	
	public KeywordTypeList getAllKeywordTypes() throws OnBaseAPIException{
		APIConnection api = new APIConnection();
		Application app= null;
			
		
		try{
			//verificamos si los parametros de la conexi�n existen.
			if(this.conn!= null){
				
				//realizamos la conexi�n.
				 app = api.openConnection(conn);
					
					//verificamos si esta hay conexi�n.
					if(app.getIsConnected()){						
						Core core = app.getCore();
						lista = core.getKeywordTypes();
						
						
					
					}else{
						
						throw new OnBaseAPIException(Mensajes.ERROR_CONEXION);
						
					}
			}else{
				throw new OnBaseAPIException(Mensajes.ERROR_PARAMETROS_CONEXION);
				
			}	//termina condicion que verifica si los parametros de conexi�n existen.							
			
		}catch(UnityAPIException ex){			
			throw new OnBaseAPIException(ex);
			
		}catch(NullPointerException e){
			throw new OnBaseAPIException(e);
		}
		finally{
			if(app != null && app.getIsConnected()){
				if(api.closeConnection( app))
					throw new OnBaseAPIException(Mensajes.ERROR_CONEXION_CERRAR+ Calendar.getInstance().getTime());
			}
		}
		
					
		return lista;
	}
	
	/**
	 * metodo que  busca una palabra clave por id.
	 * @param id: id de la palabra clave.
	 * @return
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 * @throws UnityAPIException
	 *  @throws OnBaseAPIException
	 */
	public KeywordType findKeywordTypeById(long id)
			throws OnBaseAPIException{
		
		 KeywordType key= null;
		 
		try{
			
			 if(lista ==null){		
				 lista = this.getAllKeywordTypes();			 
			 }
			 
			 
			 key= lista.Find(id);	
			 
		 
		}catch(UnityAPIException ex){			
			throw new OnBaseAPIException(ex);
			
		}catch(NullPointerException ex){				
			throw new OnBaseAPIException(ex);
			
		}
		
		if(key == null)
			throw new OnBaseAPIException(Mensajes.ERROR_MSJ_findKeywordTypeById);
		return key;
		
		
	}
	
	/**
	 * busca una palabra clave por la descripci�n.
	 * @param descripcion
	 * @return
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 * @throws UnityAPIException
	 * @throws SecurityException 
	 * @throws OnBaseAPIException 
	 */
	public KeywordType getKeywordTypesByDescription(String descripcion)
			throws  OnBaseAPIException{
		
		KeywordType key = null;
		
		try{
			if(lista ==null){		
				 lista = this.getAllKeywordTypes();			 
			 }
			key =lista.Find(descripcion);
			
			
		
		}catch(UnityAPIException ex){			
			throw new OnBaseAPIException(ex);
			
		}catch(NullPointerException ex){				
			throw new OnBaseAPIException(ex);
			
		}
		
		if(key == null)
			throw new OnBaseAPIException(Mensajes.ERROR_MSJ_getKeywordTypesByDescription);
		
		return key;
	}
}
