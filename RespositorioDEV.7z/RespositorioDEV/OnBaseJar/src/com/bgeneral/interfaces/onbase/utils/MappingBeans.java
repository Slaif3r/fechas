package com.bgeneral.interfaces.onbase.utils;

import com.bgeneral.interfaces.exception.OnBaseAPIException;

import Hyland.Unity.DocumentType;
import Hyland.Unity.Rendition;
import Hyland.Unity.UnityAPIException;

public class  MappingBeans {
	
	
	/**
	 * M�todo para mapear del objeto Rendition de onBase hacia un objeto propio de este JAR.
	 * @param rendition
	 * @return
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 * @throws UnityAPIException
	 * @throws Exception
	 * 
	 */
	public com.bgeneral.interfaces.beans.Rendition mappingRendition( Rendition rendition)
			throws InstantiationException, IllegalAccessException, UnityAPIException{
		
		com.bgeneral.interfaces.beans.Rendition re = new com.bgeneral.interfaces.beans.Rendition();

		re.setComment(rendition.getComment());
		re.setCreationDate(rendition.getCreationDate());
		re.setGetId(rendition.getID());
//		re.setImaging(rendition.getImaging());
		re.setName(rendition.getName());
		re.setNumberOfPages(rendition.getNumberOfPages());
//		re.setRevision(rendition.getRevision());
		return re;
	}
	
	


}
