package com.bgeneral.interfaces.onbase.services;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import com.bgeneral.interfaces.beans.Connection;
import com.bgeneral.interfaces.connection.APIConnection;
import com.bgeneral.interfaces.exception.OnBaseAPIException;
import com.bgeneral.interfaces.onbase.utils.Mensajes;

import Hyland.Unity.Application;
import Hyland.Unity.Core;
import Hyland.Unity.DocumentType;
import Hyland.Unity.DocumentTypeList;
import Hyland.Unity.UnityAPIException;

public class DocumentTypeServices {
	
	Connection conn = new Connection();
	
	public DocumentTypeServices(Connection conexion ){
		this.conn = conexion;
	}
	
	/**
	 * Metodo que obtiene todos los tipos de documentos.
	 * @return retorna una lsita de tipo com.bgeneral.interfaces.beans.DocumentType
	 * @throws OnBaseAPIException
	 */
	
	public List<com.bgeneral.interfaces.beans.DocumentType> getAllDocumentTypes() 
			throws OnBaseAPIException{					
		
		APIConnection api = new APIConnection();
		Application app= null;
		List<com.bgeneral.interfaces.beans.DocumentType> documentType;
		
		try{
			//verificamos si los parametros de la conexi�n existen.
			if(this.conn!= null){
				
				//realizamos la conexi�n.
				 app = api.openConnection(conn);
					
					//verificamos si esta hay conexi�n.
					if(app.getIsConnected()){						
						
						Core core = app.getCore();
						
						documentType = mappgingDocumentType(core.getDocumentTypes());
					}else{
						
						throw new OnBaseAPIException(Mensajes.ERROR_CONEXION);
						
					}
			}else{
				throw new OnBaseAPIException(Mensajes.ERROR_PARAMETROS_CONEXION);
				
			}	//termina condicion que verifica si los parametros de conexi�n existen.
			
		}catch(UnityAPIException ex){			
			throw new OnBaseAPIException(ex);
			
		} catch (InstantiationException e) {			
			throw new OnBaseAPIException(e);
			
		} catch (IllegalAccessException e) {			
				throw new OnBaseAPIException(e);
				
		}catch(NullPointerException e){
			throw new OnBaseAPIException(e);
		}
		finally{
			if(app != null && app.getIsConnected()){
				if(api.closeConnection( app))
					throw new OnBaseAPIException(Mensajes.ERROR_CONEXION_CERRAR+ Calendar.getInstance().getTime());
			}
		}
		return documentType;
	}
	
	
	
	
	/**
	 * M�todo de uso exclusivo para este JAR.
	 * @return  retorna un objeto de tipo DocumentTypeList del API de OnBase.
	 * @throws OnBaseAPIException
	 */
	protected DocumentTypeList getAllDocumentTypesOnBase() throws OnBaseAPIException{
		
		APIConnection api = new APIConnection();
		Application app= null;
		DocumentTypeList documentTypeList;
		try{
			//verificamos si los parametros de la conexi�n existen.
			if(this.conn!= null){
				
				//realizamos la conexi�n.
				 app = api.openConnection(conn);
					
					//verificamos si esta hay conexi�n.
					if(app.getIsConnected()){						
						
						Core core = app.getCore();											
						
						documentTypeList = core.getDocumentTypes();
						
					}else{
						
						throw new OnBaseAPIException(Mensajes.ERROR_CONEXION);
						
					}
			}else{
				throw new OnBaseAPIException(Mensajes.ERROR_PARAMETROS_CONEXION);
				
			}	//termina condicion que verifica si los parametros de conexi�n existen.
			
			
		}catch(UnityAPIException ex){
			
			throw new OnBaseAPIException(ex);
			
		}catch(NullPointerException e){
			throw new OnBaseAPIException(e);
		}
		finally{
			if(app != null && app.getIsConnected()){
				if(api.closeConnection( app))
					throw new OnBaseAPIException(Mensajes.ERROR_CONEXION_CERRAR+ Calendar.getInstance().getTime());
			}
		}
		
		return documentTypeList;
	}
	
	
	
	/**
	 * M�todo que busca por el id del tipo de documento. 
	 * @param id: long que representa el id del tipo de documento que deseamos buscar.
	 * @return devuelve un objeto de tipo com.bgeneral.interfaces.beans.DocumentType.
	 * @throws OnBaseAPIException
	 */
	public com.bgeneral.interfaces.beans.DocumentType getDocumentTypeById( long id)
			throws OnBaseAPIException{
		
//		DocumentType documentType = lista.Find(id);
		
		com.bgeneral.interfaces.beans.DocumentType docType = new com.bgeneral.interfaces.beans.DocumentType();
		
		DocumentType documentType = null;
		try{
			DocumentTypeList lista = getAllDocumentTypesOnBase();
			
			documentType = lista.Find(id);
			
			for(DocumentType dt :  lista){
				docType = new com.bgeneral.interfaces.beans.DocumentType();
				
				docType.setId(dt.getID());
				docType.setName(dt.getName());
				
			}
		
		}catch(UnityAPIException ex){
			
			throw new OnBaseAPIException(ex);
			
		} catch(NullPointerException e){
			throw new OnBaseAPIException(e);
		}
		
	
						
		return docType;
	}
	
	/**
	 *  M�todo de uso exclusivo para este JAR.	Devuelve un tipo de documento buscado por su id.
	 * @param id: id del tipo de documento que vamos a buscar.
	 * @return devuelve un objeto Hyland.Unity.DocumentType.
	 * @throws OnBaseAPIException
	 */
	protected DocumentType getDocumentTypeByIdOnBase( long id)
			throws OnBaseAPIException{
		
		DocumentType documentType = null;
		DocumentTypeList documentTypeList = null;
		APIConnection api = new APIConnection();
		Application app= null;
		
		
		try{
			if(this.conn!= null){
							
							//realizamos la conexi�n.
				 app = api.openConnection(conn);
					
					//verificamos si esta hay conexi�n.
					if(app.getIsConnected()){	
						
						Core core = app.getCore();			
						
						documentTypeList = core.getDocumentTypes();
						documentType = documentTypeList.Find(id);
					}
			}
			
		
		}catch(UnityAPIException ex){
			
			throw new OnBaseAPIException(ex);
			
		} catch(NullPointerException e){
			throw new OnBaseAPIException(e);
			
		}finally{
			if(app != null && app.getIsConnected()){
				if(api.closeConnection( app))
					throw new OnBaseAPIException(Mensajes.ERROR_CONEXION_CERRAR+ Calendar.getInstance().getTime());
			}
		}
		
		if(documentType ==null)
			throw new OnBaseAPIException(Mensajes.ERROR_MSJ_getDocumentTypeByIdOnBase);
		return documentType;
	}
	
	
	/**
	 * metodo que busca en una lista de tipos de documentos filtrados por el nombre.	
	 * @param nombre: nombre del tipo de documento que deseamos buscar.
	 * @return retorna un objeto de tipo com.bgeneral.interfaces.beans.DocumentType
	 * @throws OnBaseAPIException
	 */
	public com.bgeneral.interfaces.beans.DocumentType getDocumentTypeByName( String nombre)
			throws OnBaseAPIException{
		
	
		APIConnection api = new APIConnection();
		Application app= null;
		com.bgeneral.interfaces.beans.DocumentType documentType = new com.bgeneral.interfaces.beans.DocumentType();
		
		try{
			//verificamos si los parametros de la conexi�n existen.
			if(this.conn!= null){
				
				//realizamos la conexi�n.
				 app = api.openConnection(conn);
					
					//verificamos si esta hay conexi�n.
					if(app.getIsConnected()){																	
						
						
						for(DocumentType dt : app.getCore().getDocumentTypes()){
							
							if(nombre.equals(nombre)){
								documentType = new com.bgeneral.interfaces.beans.DocumentType();
								
								documentType.setId(dt.getID());
								documentType.setName(dt.getName());				
								break;
							}
										
						}
						
					}else{
						
						throw new OnBaseAPIException(Mensajes.ERROR_CONEXION);
						
					}
			}else{
				throw new OnBaseAPIException(Mensajes.ERROR_PARAMETROS_CONEXION);
				
			}	//termina condicion que verifica si los parametros de conexi�n existen.
										
		}catch(UnityAPIException ex){
			
			throw new OnBaseAPIException(ex);
			
		}
		finally{
			if(app != null && app.getIsConnected()){
				if(api.closeConnection( app))
					throw new OnBaseAPIException(Mensajes.ERROR_CONEXION_CERRAR+ Calendar.getInstance().getTime());
			}
		}
		
		
			   
		return documentType;
	}
	
	/**
	 * M�todo de uso exclusivo para este JAR.
	 * Este m�todo busca dentro de todos los tipos de documentos uno en especifico basandose en su nombre.	
	 * @param nombre: campo alfan�merico del tipo de documento que vamos a buscar.
	 * @return retorna un objeto de tipo DocumentType.
	 * @throws OnBaseAPIException
	 */
	protected DocumentType getDocumentTypeByNameOnBase( String nombre)
			throws OnBaseAPIException{
		
		DocumentType documentType =null;			
		APIConnection api = new APIConnection();
		Application app= null;
		DocumentTypeList documentTypeList=null;
		
		try{
			//verificamos si los parametros de la conexi�n existen.
			if(this.conn!= null){
				
				//realizamos la conexi�n.
				 app = api.openConnection(conn);
					
					//verificamos si esta hay conexi�n.
					if(app.getIsConnected()){
						
						Core core = app.getCore();											
						
						//Buscamos la lista de los tipos de documentos que existen.
						documentTypeList = core.getDocumentTypes();
						
						//filtramos.
						documentType = documentTypeList.Find(nombre);
						
					}else{
						
						throw new OnBaseAPIException(Mensajes.ERROR_CONEXION);
						
					}
			}else{
				throw new OnBaseAPIException(Mensajes.ERROR_PARAMETROS_CONEXION);
				
			}	//termina condicion que verifica si los parametros de conexi�n existen.							
			
		}catch(UnityAPIException ex){
			
			throw new OnBaseAPIException(ex);
			
		} catch(NullPointerException e){
			throw new OnBaseAPIException(e);
		}
		finally{
			if(app != null && app.getIsConnected()){
				if(api.closeConnection( app))
					throw new OnBaseAPIException(Mensajes.ERROR_CONEXION_CERRAR+ Calendar.getInstance().getTime());
			}
		}		
				
		return documentType;
	}
	
	/**
	 * metodo que devuelve todos los tipos de documentos que contengan la palabra "CHEQUE".
	 * @return	 
	 * @throws OnBaseAPIException
	 */
	@Deprecated
	public DocumentTypeList getDocumentsTypeWithWordCheque() throws OnBaseAPIException{
		
		int contador=0;		
		APIConnection api = new APIConnection();
		Application app= null;
		DocumentTypeList dtl = null;
		
		try{
			//verificamos si los parametros de la conexi�n existen.
			if(this.conn!= null){
				
				//realizamos la conexi�n.
				 app = api.openConnection(conn);
					
					//verificamos si esta hay conexi�n.
					if(app.getIsConnected()){	
						
						Core core = app.getCore();
						System.out.println("Total de todos los documentos: "+ core.getDocumentTypes().size());
						
						dtl = core.getDocumentTypes();
						
						
						for(DocumentType dt : core.getDocumentTypes()){
							if(dt.getName().contains("Cheque")){							
								System.out.println("->"+dt.getID()+" name "+ dt.getName()+ " Display name:  "+ dt.getDocumentDateDisplayName()
								+ " doc type group: "+ dt.getDocumentTypeGroup().getName()+"-"+dt.getDocumentTypeGroup().getID() );
								contador++;
							}
							
						}
						System.out.println("Total de tipos de documentos encontrados : "+ contador);
					}else{
						
						throw new OnBaseAPIException(Mensajes.ERROR_CONEXION);
						
					}
			}else{
				throw new OnBaseAPIException(Mensajes.ERROR_PARAMETROS_CONEXION);
				
			}	//termina condicion que verifica si los parametros de conexi�n existen.							
			
		}catch(UnityAPIException ex){
			
			throw new OnBaseAPIException(ex);
			
		} catch(NullPointerException e){
			throw new OnBaseAPIException(e);
		}
		finally{
			if(app != null && app.getIsConnected()){
				if(api.closeConnection( app))
					throw new OnBaseAPIException(Mensajes.ERROR_CONEXION_CERRAR+ Calendar.getInstance().getTime());
			}
		}
		

		return dtl;
	}
	
	/**
	 * 
	 * M�todo privado que recorre un objeto DocumentTypeList para obtener su informaci�n y mapearla a un objeto propio
	 * de este JAR:
	 * @param documentTypeList: objeto de tipo Hyland.Unity.DocumentTypeList.
	 * @return retorna una lista de tipo List<com.bgeneral.interfaces.beans.DocumentType>.
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 * @throws UnityAPIException
	 * @throws NullPointerException
	 */
	private List<com.bgeneral.interfaces.beans.DocumentType> mappgingDocumentType(DocumentTypeList documentTypeList)
			throws InstantiationException, IllegalAccessException, UnityAPIException, NullPointerException {
		
		
		List<com.bgeneral.interfaces.beans.DocumentType> listaDocumentType = new ArrayList<>();
		com.bgeneral.interfaces.beans.DocumentType documentType = new com.bgeneral.interfaces.beans.DocumentType();
		
		for(DocumentType dt : documentTypeList){
			documentType = new com.bgeneral.interfaces.beans.DocumentType();
			
			documentType.setId(dt.getID());
			documentType.setName(dt.getName());
			
			listaDocumentType.add(documentType);
			
		}
		
		return listaDocumentType.size()==0 ? new ArrayList<>() : listaDocumentType;
	}
	


}
