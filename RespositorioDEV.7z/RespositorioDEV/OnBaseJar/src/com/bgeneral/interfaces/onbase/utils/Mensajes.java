/**
 * 
 */
package com.bgeneral.interfaces.onbase.utils;

/**
 * @author jsoto
 *
 */
public class Mensajes {

	//Mensajes Generales.
	public  static final String ERROR_PARAMETROS_CONEXION ="Error con los par�metros de conexi�n. No existen!.";
	public static final String ERROR_CONEXION ="Ha ocurrido un error al momento de realizar la conexi�n.";
	public static final String ERROR_CONEXION_CERRAR="Error al momento de cerrar la conexi�n. ";
	
	//Mensajes de DocumentTypeGroupServices.
	public static final String ERROR_MSJ_getAllDocumentTypeByGroupOnBase ="Ocurri� un error en el m�todo getAllDocumentTypeByGroupOnBase.";
	public static final String ERROR_MSJ_findDocumentTypeGroupOnBase ="Ocurri� un error en el m�todo findDocumentTypeGroupOnBase.";		//por id.
	public static final String ERROR_MSJ_findDocumentTypeGroupOnBase2 ="Ocurri� un error en el m�todo findDocumentTypeGroupOnBase.";	//por descripci�n
	public static final String ERROR_MSJ_getDocumentTypeGrouByNameOnBase ="Ocurri� un error en el m�todo getDocumentTypeGrouByNameOnBase.";
	public static final String ERROR_MSJ_getDocumentTypeGroupByIdOnBase ="Ocurri� un error en el m�todo getDocumentTypeGroupByIdOnBase.";
	
	
	//Mensajes de DocumentTypeServices.
	public static final String ERROR_MSJ_getDocumentTypeByIdOnBase="Ocurri� un error en el m�todo getDocumentTypeByIdOnBase.";	
	
	//Mensaje de KeywordTypesServices
	public static final String ERROR_MSJ_findKeywordTypeById="Ocurri� un error en el m�todo findKeywordTypeById.";
	public static final String ERROR_MSJ_getKeywordTypesByDescription="Ocurri� un error en el m�todo getKeywordTypesByDescription.";
	
	//Mensajes de DocumentServices.
	public static final String ERROR_MSJ_findDocumentsByDateRangeAndDocumentType="No se puede realizar una b�squeda por la descripci�n de un tipo de documento.";
}
