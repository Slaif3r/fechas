package com.bgeneral.interfaces.onbase.services;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bgeneral.interfaces.beans.Connection;
import com.bgeneral.interfaces.beans.Document;
import com.bgeneral.interfaces.exception.OnBaseAPIException;

import Hyland.Unity.Application;
import Hyland.Unity.DocumentType;
import Hyland.Unity.DocumentTypeGroup;
import Hyland.Unity.DocumentTypeGroupList;
import Hyland.Unity.DocumentTypeList;
import Hyland.Unity.OnBaseAuthenticationProperties;
import Hyland.Unity.UnityAPIException;

public class Test {
	public static void main (String[] args) throws InstantiationException, IllegalAccessException{			
		
//		methodLinneker();
//		methodJuly();	
		methodJuly2();
		
//		testConnection();
				
	}
	
	
	
	public static void methodLinneker(){
		
			System.out.println("try connect!!!...");
			OnBaseAuthenticationProperties auth = Application.CreateOnBaseAuthenticationProperties("http://bgcldesaonbwap/AppServer/service.asmx", "cheques", "cheques", "ORAONPRU");
			Application onbase = Application.Connect(auth);
				
			
			
			
			onbase.Disconnect();
			onbase.close();
			System.out.println(onbase.getIsConnected());
				
			
			
		
	}
	
	
	/**
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 * @throws NoSuchMethodException 
	 * @throws UnityAPIException 
	 * throws InstantiationException, IllegalAccessException, UnityAPIException
	 */
	public static void methodJuly() throws InstantiationException, IllegalAccessException, UnityAPIException {

	



		try{
			
				Connection conexion  = new Connection();
				conexion.setUrl("http://bgcldesaonbwap/AppServer/service.asmx");
				conexion.setUser("cheques");
				conexion.setPass("cheques");
				conexion.setDataSource("ORAONPRU");
					
				
				
//			FolderServices folderServices = new FolderServices( core);
//			folderServices.getAllFolders();
			

			DocumentTypeServices dts = new DocumentTypeServices(conexion);
//			dts.getAllDocumentTypes();
			
			
			
			DocumentTypeGroupServices dtgs = new DocumentTypeGroupServices(conexion);
			
			//Obtengo todos los grupo de tipos de documentos.
			dtgs.getAllDocumentTypeGroup();

			
			
		
		
			
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			
			Calendar cal = Calendar.getInstance();
		
		
			cal.add(Calendar.DATE, -5000);		
			Date fechaInicio = cal.getTime();
			
			cal = Calendar.getInstance();
			Date fechaFinal = cal.getTime();
			
//		
			   
			
			
			
			
//			KeywordType keywordType = keysServices.findKeywordTypeById(102);
			
			//se busca por la descripci�n. NOTA: la descripcion debe ser igual. Si no no encuentra nada.
			
				
//			KeywordType keywordType1 = keysServices.getKeywordTypesByDescription("Chequenum");
							
				//tipo de cheque
//			List<String> lista = listKeywordTypes();
			
//			for(String l : lista){
//			ds.findDocumentByKeyword(l, 1000);
//			}
			

			//busca documentos por medio de una palabra clave.
//			ds.findDocumentByKeyword("Chequenum", 1000);
			
		
			
		} catch (OnBaseAPIException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
//		catch (OnBaseAPIException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		finally{
//			System.out.println("Desconectando...");
		
			
//			app.Disconnect();
//			app.close();

//			System.out.println("Desconectado");
//			System.out.println("�Existe Conexi�n? "+app.getIsConnected());

		}
	

	}
	
	public static void methodJuly2(){
		Connection conexion  = new Connection();
		conexion.setUrl("http://bgcldesaonbwap/AppServer/service.asmx");
		conexion.setUser("cheques");
		conexion.setPass("cheques");
		conexion.setDataSource("ORAONPRU");
		conexion.setTimeOut(50000);
		
//		Connection conexion = null;
		
		DocumentServices ds = new DocumentServices(conexion);
		DocumentTypeServices dts = new DocumentTypeServices(conexion);
		DocumentTypeGroupServices dtgs = new DocumentTypeGroupServices(conexion);
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		
		Calendar cal = Calendar.getInstance();
	
	
		cal.add(Calendar.DATE, -5000);		
		Date fechaInicio = cal.getTime();
		
		cal = Calendar.getInstance();
		Date fechaFinal = cal.getTime();
		
		try {						
			
					//buscar documento por id. 105898733
//					ds.getDocumentById(105899562);	
					
//					dts.getDocumentsTypeWithWordCheque();
					

					
														
					
					
					
			
			
															
					
					
					//DOCUMENTTYPEGROUPSERVICES.
									
					//Obtengo todos los grupo de tipos de documentos. Los mapea a un java beans del JAR.
//					List<com.bgeneral.interfaces.beans.DocumentTypeGroup> listaGrupos = dtgs.getAllDocumentTypeGroup();
				
					//devuelve todos los grupo de tipos de documentos.
//					DocumentTypeGroupList ll = dtgs.getAllDocumentTypeGroupOnBase();
					
					//M�todo que obtiene un grupo de tipo de documento ya sea por el id o por el nombre. El sobrecargado el metodo.
//					com.bgeneral.interfaces.beans.DocumentTypeGroup docTypeGroupBase = dtgs.findDocumentTypeGroup(101);
															//					
					
					// Se obtiene un objeto DocumentTypeGroup por medio del id. ID= 101 = cuentas corrientes
//					DocumentTypeGroup documentTypeGroup = dtgs.findDocumentTypeGroupOnBase( 101);
					
					
					
					
					
					
					//DOCUMENTTYPESERVICES.
			
					//busca todos los tipos de documentos que existen.
//					DocumentTypeList listaDocs = dts.getAllDocumentTypesOnBase();
				
					//busca un tipo de documento por descripcion.
//					DocumentType documentType1= dts.getDocumentTypeByNameOnBase( "Imagenes de Cheques");
					
//					com.bgeneral.interfaces.beans.DocumentType dt = dts.getDocumentTypeByName("Imagenes de Cheques");
					
					
					//buscamos un tipo de documento en onBase por medio del id del mismo.
//					DocumentType dt = dts.getDocumentTypeByIdOnBase( 1599);	//swift
					
					//m�todo que regresa un tipo de documento buscado propio del JAR. filtrado por el id.
//					com.bgeneral.interfaces.beans.DocumentType dt2= dts.getDocumentTypeById( 101);
					
					
					
					//busca una lista de tipos de documentos filtradas por el nombre del grupo de tipo de documentos.
//					DocumentTypeList documentTypeList = dtgs.getAllDocumentTypeByGroupOnBase( "cuentas corrientes");
					
					//lo mismo que el de arriba solo que una lista de un java bean propio de este JAR.
//					List<com.bgeneral.interfaces.beans.DocumentType> doctType2 = dtgs.getAllDocumentTypeByGroup( "cuentas corrientes");
					
					
					
					
					
					//DOCUMENTSERVICES.
								
					//buscamos por el id del grupo de tipo de documento.
//					List<Document> docs1 =ds.getDocumentsByDocumentTypeGroup(101, 100,"I");
					
					//en este metodo se pasa el id del tipo de documento y la cantidad de registros que deseamos desplegar.
//					List<Document> docs2 = ds.getDocumentsByIdDocumentType(101, 1000,"I");
					
					//metodo que busca una lisa de documentos por medio del nombre del tipo de documento.
//					List<Document> docs3 = ds.getDocumentByNameOfDocumentType("Imagenes de Cheques", 100, "I");
					
					//buscar un documento por id.
//					com.bgeneral.interfaces.beans.Document doc = ds.getDocumentById(docs2, 105898733);
					
												
//					ds.getDocumentByRange( 5000, 105899394, 105899395, "I");
					
					
//					ds.getDocumentById(105899538);
					
//					ds.findDocumentsDateRange(fechaInicio, fechaFinal,"I", 5000);
					
					
					
					/*busca cheques por rango de fechas. El tipo de documento (documentType) debe ser de tipo cheque. 
					 * Tambi�n aplica para cualquier otro tipo de documento.*/
//					ds.findDocumentsByDateRangeAndDocumentType(fechaInicio, fechaFinal, 100, null, 101, "I");
					
					//busca los documentos por un rango de fecha y n�mero de cuenta.
//					ds.findDocumentsByDateRangeAndAccount(fechaInicio, fechaFinal, 5000, "0301010672188");
			
	
					
//					ds.findDocumentByKeyword("Cuenta de Cheque",I ,5000);
					
//					ds.findDocumentByKeywordAndDateRange(fechaInicio, fechaFinal, "chequenum", "I", 5000);
					
//					ds.getDocumentList(fechaInicio, fechaFinal, "chequenum", 5000, 101, 101, "0305010785015", 1, 100);
					
					
					Map<String, Object> mapa = new HashMap<>();
					
//					mapa.put("numero_cuenta", "0305010785015");
//					mapa.put("fecha", fechaInicio);
//					mapa.put("numero_cheque", 100);
//					mapa.put("numero_pagina", 1);
					mapa.put("num_cheque", "Cuentanum");
					
					/*
					 * I= imagen, documentos como tal.
					 * P = si se quiere extraer el documento en PDF
					 * T= si se quiere extraer el documento como texto, esto para los reportes.
					 * */
					ds.getDocumentList(mapa, 10, 101, 101, "I");
					
					
					//KEYWORDTYPESERVICES.
					KeywordTypesServices keysServices =new KeywordTypesServices(conexion);
					
//					KeywordTypeList keywordTypeL = keysServices.getAllKeywordTypes();
					
		} catch ( OnBaseAPIException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public static void testConnection(){
	
		String nombre="julio";
		long edad=33;
		
		
		System.out.println(Integer.parseInt(nombre));
		
	}
	public static List<String> listKeywordTypes(){
		
		List<String> lista = new ArrayList<>();
	
		lista.add("ABA");
		 lista.add("Account #");
		 lista.add("Alias");
		 lista.add("Apartado");
		 lista.add("chequenum");
		 lista.add("Apellido Casada");
		 lista.add("Area");
		 lista.add("A�o");
		 lista.add("BG Apellido de Casada");
		 lista.add("BG Apellidos");
		 lista.add("BG Cantidad Aprobada");
		 lista.add("BG Celular");
		 lista.add("BG Ciudad");
		 lista.add("BG Codigo Ejecutivo");
		 lista.add("BG Codigo Forma Pago");
		 lista.add("BG Codigo Fuente de Pago");
		 lista.add("BG Codigo Oficial");
		 lista.add("BG Codigo Oficina");
		 lista.add("BG Codigo Poliza");
		 lista.add("BG Codigo Programa");
		 lista.add("BG Codigo Ruta");
		 lista.add("BG Codigo Sectores");
		 lista.add("BG Codigo Sub Sector");
		 lista.add("BG Codigo Subsidio");
		 lista.add("BG Codigo Tipo Operacion");
		 lista.add("BG Codigo Tipo Producto");
		 lista.add("BG Codigo Tipo Tramite");
		 lista.add("BG Codigo Uso de Fondos");
		 lista.add("BG Codigo Usuario");
		 lista.add("BG Codigo de Rechazo");
		 lista.add("BG Compa�ia");
		 lista.add("BG Compa��a");
		 lista.add("BG Correo Electr�nico");
		 lista.add("BG Correo OnBase");
		 lista.add("BG Correo Usuario");
		 lista.add("BG C�digo Postal");
		 lista.add("BG Deudor");
		 lista.add("BG Dignatario");
		 lista.add("BG Direcci�n 1");
		 lista.add("BG Direcci�n 2");
		 lista.add("BG Fecha Digitalizado");
		 lista.add("BG Fecha Recibido");
		 lista.add("BG Fecha de Apertura");
		 lista.add("BG Fecha/Hora Digitalizado");
		 lista.add("BG Fecha/Hora Recibido");
		 lista.add("BG Fiador");
		 lista.add("BG Firmante");
		 lista.add("BG Garante");
		 lista.add("BG L�mite de Riesgo");
		 lista.add("BG Nombre");
		 lista.add("BG Nombre Completo");
		 lista.add("BG Nombre Usuario");
		 lista.add("BG N�mero Identificaci�n");
		 lista.add("BG N�mero de Ente");
		 lista.add("BG Origen del error");
		 lista.add("BG Pa�s");
		 lista.add("BG Re utilizar");
		 lista.add("BG Subsidiaria");
		 lista.add("BG Tel�fono");
		 lista.add("BG Tipo de Identificaci�n");
		 lista.add("BG Tipo de Participaci�n");
		 lista.add("BG Tipo de Reproceso");
		 lista.add("BG Tipo de Tramite");
		 lista.add("BG Tipos Documentales");
		 lista.add("BG Usuario");
		 lista.add("BG Usuarios OnBase");
		 lista.add("BG Vendedor");
		 lista.add("BGOP Aseguradora");
		 lista.add("BGOP Asignado");
		 lista.add("BGOP Control de Error");
		 lista.add("BGOP Devuelto por");
		 lista.add("BGOP DocID");
		 lista.add("BGOP Enviado A");
		 lista.add("BGOP Estado Anterior");
		 lista.add("BGOP Operacion");
		 lista.add("BGOP Refinanciamiento");
		 lista.add("BGOP Solicitado Para");
		 lista.add("BGOP Solicito Fisico");
		 lista.add("BGOP Sucursal");
		 lista.add("BGOP Sucursaln");
		 lista.add("BGOP Tipo de Cancelacion");
		 lista.add("BGOP Tipo de Solicitud");
		 lista.add("BGOP Tipo de Tramite");
		 lista.add("BGOP sublocation1");
		 lista.add("BGOP sublocation2");
		 lista.add("BGOP sublocation3");
		 lista.add("BGOP sublocation4");
		 lista.add("BGUTL T1");
		 lista.add("BGUTL T10");
		 lista.add("BGUTL T2");
		 lista.add("BGUTL T3");
		 lista.add("BGUTL T4");
		 lista.add("BGUTL T5");
		 lista.add("BGUTL T6");
		 lista.add("BGUTL T7");
		 lista.add("BGUTL T8");
		 lista.add("BGUTL T9");
		 lista.add("Banca Inversion");
		 lista.add("Banco");
		 lista.add("Banco (Ruta)");
		 lista.add("Batch");
		 lista.add("Batch #");
		 lista.add("Batch Amount");
		 lista.add("Batch Number");
		 lista.add("Build Version");
		 lista.add("CE Abogado/Licenciado");
		 lista.add("CE Arquitecto");
		 lista.add("CE Asistente");
		 lista.add("CE Asistente Gestion Documentacion");
		 lista.add("CE CPP?");
		 lista.add("CE Categoria Plantilla");
		 lista.add("CE Causa de Rechazo");
		 lista.add("CE Comentarios");
		 lista.add("CE Comentarios AID");
		 lista.add("CE Comision");
		 lista.add("CE Comision COMEXT");
		 lista.add("CE Condiciones Financieras");
		 lista.add("CE Contructor");
		 lista.add("CE Desembolso");
		 lista.add("Transaction #");
		 lista.add("Transaction Code");
		 lista.add("Versi�n de Contrato");
//		 lista.add("WF90DayCounter");
//		 lista.add("WFCallPeopleSoft");
		 lista.add("WFCargoHasta");
		 lista.add("WFCargoInter");
		 lista.add("WFCargoMember");
		 lista.add("WFCargoPanama");
		 lista.add("WFCargoPerdida");
		 lista.add("WFCargoSeguro");
		 lista.add("WFComplete");
		 lista.add("WFCompletionTime");
//		 lista.add("WFContractPrinted");
		 lista.add("WFContractType");
//		 lista.add("WFDayCounter");
		 lista.add("WFErrorCode");
		 lista.add("WFExtensionTime");
		 lista.add("WFFinalTime");
		 lista.add("WFMessageService");
		 lista.add("WFMethodCalled");
		 lista.add("WFNewUser");
		 lista.add("WFPeopleSoftStatus");
		 lista.add("WFQueueName");
		 lista.add("WFScriptError");
		 lista.add("WFStatus");
		 lista.add("WFSupervisor");
		 lista.add("WFTempAF");
		 lista.add("WFTempHolder");
		 lista.add("WFTempHolder2");
		 lista.add("WFTempNote");
		 lista.add("WFTotalBusinessDays");
		 lista.add("WFUser");
		 lista.add("WSDL Output Code");
		 lista.add("WSDL Output Message");
		 lista.add("Work Mode Code");
		 lista.add("Year");
		 lista.add("Zip Code");
		 lista.add("Zona Postal");
//		 lista.add("de Casada");
		 lista.add("i_plantilla");
		 lista.add("i_tramite");
		 lista.add("i_tramiteold");
		 lista.add("iplantilla");
		 lista.add("itramite");
		 lista.add("tipo_cesion");
		 lista.add("tipo_destino");
		 lista.add("OLDN�mero de Sucursal");
		return lista;
	}
	

	
}
