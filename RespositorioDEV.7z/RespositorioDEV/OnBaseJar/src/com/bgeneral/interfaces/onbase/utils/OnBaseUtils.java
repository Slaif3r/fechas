/**
 * 
 */
package com.bgeneral.interfaces.onbase.utils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import Hyland.Unity.Core;
import Hyland.Unity.FileType;
import Hyland.Unity.FileTypeList;
import Hyland.Unity.PageData;

/**
 * @author jsoto
 *
 */
public class OnBaseUtils {

	/**
	 * m�todo que imprime los valores que nos devuelve el inputStream.
	 * @param data
	 * @throws IOException
	 */
	public void printInputStream(PageData data) throws IOException{
		

		int i=0;
		char c;
		String cadena="";
		
		while( (i=data.getStream().read())!=1){
			
			c=(char)i;
			
//			System.out.println(c);
			cadena+=c;
		}

		System.out.println(cadena);
	}
	
	public List<String> getFilesTypes( Core core){
		
		List<String> lista = new ArrayList<>();
		
		FileTypeList files = core.getFileTypes();
		
		
		
		return lista;
	}
}
