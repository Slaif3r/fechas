/**
 * 
 */
package com.bgeneral.interfaces.connection;

import com.bgeneral.interfaces.beans.Connection;

import Hyland.Unity.Application;
import Hyland.Unity.AuthenticationProperties;
import Hyland.Unity.LicenseType;
import Hyland.Unity.MaxConcurrentLicensesException;
import Hyland.Unity.OnBaseAuthenticationProperties;
import Hyland.Unity.UnityAPIException;

/**
 * @author jsoto
 *
 */
public class APIConnection {

	Application app = null;
	
	public Application openConnection(Connection conn)
			throws MaxConcurrentLicensesException ,UnityAPIException{
		
		
		AuthenticationProperties auth = Application.CreateOnBaseAuthenticationProperties(conn.getUrl(), conn.getUser(), conn.getPass(), conn.getDataSource());
	
		auth.setLicenseType(LicenseType.QueryMetering);
		
		Application app = Application.Connect(auth);
//					app.setTimeout(conn.getTimeOut());
	
		return app;
		
	}
	
	public boolean closeConnection(Application app) throws UnityAPIException {			
					
			app.Disconnect();
			app.close();	
			System.out.println("�Hay conexion: ?"+ app.getIsConnected());
		return app.getIsConnected();
		
	}
}
