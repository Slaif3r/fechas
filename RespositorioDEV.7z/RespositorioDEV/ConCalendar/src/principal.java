import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;


public class principal {

	 public Date sumarRestarDiasFecha(Date fecha, int dias)	{
		 	Calendar  calendar = Calendar.getInstance();
		       calendar.setTime(fecha); // Configuramos la fecha que se recibe
		       calendar.add(Calendar.DAY_OF_YEAR, dias);  // numero de d�as a a�adir, o restar en caso de d�as<0
		       return calendar.getTime(); // Devuelve el objeto Date con los nuevos d�as a�adidos
		  }
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		
		
		String pattern = "yyyy-MM-dd";
		SimpleDateFormat format = new SimpleDateFormat(pattern);
		try {
		  Date date = format.parse("2017-07-15");
		  Date aux = date;
		  System.out.println(date);
		} catch (ParseException e) {
		  e.printStackTrace();
		}
		Calendar calendario = GregorianCalendar.getInstance();
		Date fecha = calendario.getTime();
		System.out.println(fecha);
		
	      //Date prueba = sumarRestarDiasFecha(fecha, 15);
	}

}
