package com.bgeneral.canales.pagorecurrente;

import java.time.LocalDate;


public class UtilidadesRangoPago {
	
	private static LocalDate calcularrango (LocalDate fecha_inicial){
		LocalDate  fecha_actual = null;
			
		
		return fecha_actual;
	} 

}
