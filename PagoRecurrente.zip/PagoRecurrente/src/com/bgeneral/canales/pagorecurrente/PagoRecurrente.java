	/**************************************************************************/
	/*    ARCHIVO: Recurrente.java                                            */ 
	/*    NOMBRE LOGICO: Recurrente                                           */
	/*    PRODUCTO: Banca en Linea                                            */
	/**************************************************************************/
	/*                     IMPORTANTE                                         */
	/* Este programa fue disenado por Banco General, S.A., y esta protegido   */
	/* por los derechos de propiedad intelectual.  Su uso no autorizado queda */
	/* expresamente prohibido de acuerdo a la legislacion vigente, asi como   */
	/* obtener una copia (total o parcial) para fines ajenos al banco, sin el */
	/* consentimiento de la Vice Presidencia Ejecutiva del Banco General, S.A.*/
	/**************************************************************************/
	/*                          PROPOSITO                                     */
	/*Aplicacion que permite calcular la fecha de los pagos recurrentes       */
	/*de acuerdo al modelo especificado por el cliente.                       */ 
	/****************************  MODIFICACIONES  ****************************/
	/*   FECHA               AUTOR                  RAZON                     */
	/* 10-6-2016	Christopher Mitchell	Adecuaciones t�cnicas             */
	/* 28-7-2016	Christopher Mitchell	Cambio de nombre a paquete        */
	/* 27-6-2017    Aristides A. Morcillo	Actualizacion debido a Error al   */
	/* dar las fechas..----------------------------------------------------    */
    /*                                                                        */
	/**************************************************************************/
package com.bgeneral.canales.pagorecurrente;


import java.time.LocalDate;  
import java.util.ArrayList;
import java.util.List;
import java.time.DayOfWeek;


public class PagoRecurrente {
	private static LocalDate fecha_aux1,fecha_aux2;//
	private static boolean cargarFechas = false;////Variables para poder iterar sobre las quincenas.

		private static LocalDate calcularSiguiente(String num_dias,  LocalDate fecha_actual, int i) throws OpcionNoExisteException {
			
			switch (num_dias) {
			
			case "1": // DIARIO
				fecha_actual  = fecha_diaria(fecha_actual,i);
				break;

			case "15": // ANUAL 
				fecha_actual  = fecha_actual.plusYears(1);
				break;

			case "16": // SEMANAL
				fecha_actual  = fecha_actual.plusWeeks(1); 
				break;

			case "2": // QUINCENAL 
				fecha_actual = fecha_Quincenal(i,fecha_actual);
				break;

			case "4": // MENSUAL 
				fecha_actual  = fecha_actual.plusMonths(1);
				break;

			case "5": // BIMESTRAL 
				fecha_actual  = fecha_actual.plusMonths(2);
				break;

			case "6": // TRIMESTRAL
				fecha_actual  = fecha_actual.plusMonths(3);
				break;
				
			case "7": // CUATRIMESTRAL
				fecha_actual  = fecha_actual.plusMonths(4);
				break;
				
			case "9": // SEMESTRAL
				fecha_actual  = fecha_actual.plusMonths(6);
				break;
				
			default:
		
				throw new OpcionNoExisteException("No existe la opcion seleccionada");
			}
			return fecha_actual;
		}

		
		//Programa Inicia por aqu�.
		public static List<LocalDate> obtener_fecha_pagos(LocalDate fecha_inicial,int num_pagos,String num_dias) throws OpcionNoExisteException { 
			  
			  LocalDate fecha_actual = null;  // Lista tipo fecha
			  List<LocalDate> listaFechas = new ArrayList<LocalDate>();
			  	 
			  fecha_actual=fecha_inicial;
			  if(num_pagos!=1){
			  for(int i=1;i<=num_pagos;i++) {
				  if (i==1){
					  listaFechas.add(evaluarDomingo(fecha_inicial));
				  }
				  else if(num_dias != "1"){
					  fecha_actual= calcularSiguiente(num_dias, fecha_actual,i); //Se hace el llamado a la funcion para guardar la siguiente fecha y agregarla a la lista.
					  listaFechas.add(evaluarDomingo(fecha_actual));}
				  else if (num_dias == "1")//evalua si es diario.
				  {fecha_actual = calcularSiguiente(num_dias, fecha_actual,i);
				   listaFechas.add(evaluarDomingo(fecha_actual));
				  }
			  }
			  }
			  else
				  listaFechas.add(evaluarDomingo(fecha_inicial));
			  return listaFechas; //Retorna la lista con las fechas a�adidas.
			} 
		
		
		public static LocalDate fecha_Quincenal(int i,LocalDate fechaInicial){
			LocalDate fechaRetorno;
			if(!cargarFechas){
				fecha_aux1=fechaInicial;
				fecha_aux2=fechaInicial.plusDays(15);
				cargarFechas=true;
				
			}
			
			if(i%2==0){// se verifica si el mes es de 30 o 31 dias para proceder con el calculo de los dias.
				fechaRetorno=fecha_aux2;
				fecha_aux1=fecha_aux1.plusMonths(1);
			}else{
				fechaRetorno=fecha_aux1;
				fecha_aux2=fecha_aux2.plusMonths(1);
			}
			
			
			return fechaRetorno;
		}
		
		public static LocalDate evaluarDomingo(LocalDate fechaAEvaluar)
		{
			if (fechaAEvaluar.getDayOfWeek() == DayOfWeek.SUNDAY) 
		    {
				fechaAEvaluar=fechaAEvaluar.minusDays(1);
		    	
		     }
		    
			
			return fechaAEvaluar;
		}
		
		public static LocalDate fecha_diaria(LocalDate fechaInicial,int i){
			
			 if (fechaInicial.getDayOfWeek() == DayOfWeek.SATURDAY){
				 fechaInicial = fechaInicial.plusDays(2);
			 }else {fechaInicial = fechaInicial.plusDays(1);}
			
			return fechaInicial;
		}
		
}